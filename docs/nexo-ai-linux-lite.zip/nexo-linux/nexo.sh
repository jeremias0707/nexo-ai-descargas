#!/bin/bash
# Lanzador NEXO AI Linux Lite
cd "$(dirname "$0")" || exit 1
if command -v python3 >/dev/null 2>&1; then
  exec python3 nexo_linux.py "$@"
elif command -v python >/dev/null 2>&1; then
  exec python nexo_linux.py "$@"
else
  echo "No encontré python3 ni python. Instalá Python 3 + Tkinter."
  echo "Ver LEEME.txt"
  exit 1
fi
