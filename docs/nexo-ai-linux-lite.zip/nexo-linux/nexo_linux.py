# -*- coding: utf-8 -*-
"""NEXO AI Linux Lite — tutor liviano para Puppy/Xenial (Python 3 + Tkinter)."""
from __future__ import print_function

import json
import os
import sys
import traceback

try:
    import urllib.request as urllib_request
    import urllib.error as urllib_error
except ImportError:
    import urllib2 as urllib_request
    urllib_error = urllib_request

try:
    import tkinter as tk
    from tkinter import messagebox, scrolledtext as ScrolledText
except ImportError:
    try:
        import Tkinter as tk
        import tkMessageBox as messagebox
        import ScrolledText
    except ImportError:
        print(
            "Falta Tkinter.\n"
            "En Puppy/Linux instalá el paquete de Tk:\n"
            "  • Debian/Ubuntu/antiX:  sudo apt-get install python3-tk\n"
            "  • Puppy: buscá 'python3-tk' o 'tkinter' en el gestor de paquetes\n"
            "Después volvé a ejecutar:  python3 nexo_linux.py"
        )
        sys.exit(1)

VERSION = "3.0.2-linux-lite"
MODELS = [
    "gemini-flash-latest",
    "gemini-3.8-flash",
    "gemini-3.5-flash-lite",
    "gemini-3.6-flash",
]
MAX_TURNS = 12
SUBJECTS = [
    u"Matemática",
    u"Historia",
    u"Biología",
    u"Lengua",
    u"Química",
    u"Física",
    u"Otras",
]

APP_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(APP_DIR, "config.txt")

# Paleta pastel / papel (distinta de XP Lite)
C_BG = "#F7F3EE"          # crema
C_HEADER = "#EDE6F7"      # lavanda suave
C_CARD = "#FFFFFF"        # blanco papel
C_CHIP = "#E8F4F2"        # teal muy claro
C_CHIP_ON = "#5BB8B0"     # teal activo
C_CHIP_ON_FG = "#FFFFFF"
C_CHIP_FG = "#2F5F5A"
C_TEAL = "#3A9B94"        # bot / acento
C_CORAL = "#D96B7A"       # usuario
C_LAV = "#7B6BB0"         # sistema
C_TEXT = "#2C3338"        # texto cuerpo
C_MUTED = "#7A858C"       # status / subtítulo
C_BTN_TEAL = "#5BB8B0"
C_BTN_CORAL = "#E07A8A"
C_BTN_SOFT = "#E8E0F0"
C_INPUT_BG = "#FFFBF7"
C_OK = "#3D9B6E"
C_ERR = "#C45C5C"
C_BORDER = "#E2D9CF"


def ui_font(size=10, bold=False):
    weight = "bold" if bold else "normal"
    for family in ("DejaVu Sans", "Liberation Sans", "FreeSans", "TkDefaultFont"):
        try:
            return (family, size, weight) if bold else (family, size)
        except Exception:
            continue
    return ("TkDefaultFont", size, weight) if bold else ("TkDefaultFont", size)


def read_api_key():
    if not os.path.isfile(CONFIG_PATH):
        return ""
    try:
        f = open(CONFIG_PATH, "r")
        try:
            for line in f:
                line = line.strip()
                if line.startswith("GEMINI_API_KEY="):
                    return line[len("GEMINI_API_KEY="):].strip()
        finally:
            f.close()
    except Exception:
        return ""
    return ""


def system_prompt(subject):
    return (
        u"Sos NEXO, un tutor de estudio para estudiantes de secundaria/preparatoria "
        u"en Argentina/Uruguay. Hablá en español rioplatense natural (vos, dale, mirá), "
        u"claro y cercano, sin ser infantil. Materia actual: %s. "
        u"Explicá paso a paso. Si no estás seguro, decilo. No inventes datos. "
        u"No des respuestas solo para copiar en un examen: ayudá a entender. "
        u"Sé breve si alcanza, y más detallado si el tema lo pide. "
        u"Esta es la versión NEXO Linux Lite: no hay fotos, PDF ni plan de estudio."
    ) % subject


def http_post_json(url, payload):
    data = json.dumps(payload)
    try:
        text_type = unicode  # py2
    except NameError:
        text_type = str
    if isinstance(data, text_type) and not isinstance(data, bytes):
        data = data.encode("utf-8")
    req = urllib_request.Request(url, data=data)
    req.add_header("Content-Type", "application/json; charset=utf-8")
    try:
        resp = urllib_request.urlopen(req, timeout=60)
        raw = resp.read()
        code = getattr(resp, "code", 200)
        resp.close()
        return code, raw
    except urllib_error.HTTPError as e:
        raw = e.read()
        return e.code, raw
    except Exception:
        raise


def parse_reply(raw):
    if isinstance(raw, bytes):
        try:
            raw = raw.decode("utf-8")
        except Exception:
            raw = raw.decode("latin-1", "replace")
    obj = json.loads(raw)
    if "error" in obj:
        msg = obj["error"]
        if isinstance(msg, dict):
            return None, msg.get("message", str(msg))
        return None, str(msg)
    cands = obj.get("candidates") or []
    if not cands:
        return None, u"Respuesta vacía del modelo."
    parts = (cands[0].get("content") or {}).get("parts") or []
    texts = []
    for p in parts:
        if "text" in p:
            texts.append(p["text"])
    if texts:
        return u"\n".join(texts), None
    return None, u"Sin texto (finish=%s)" % cands[0].get("finishReason")


def call_gemini(history, subject, user_text):
    key = read_api_key()
    if not key or len(key) < 10:
        return None, None, (
            u"Falta GEMINI_API_KEY en config.txt. "
            u"Conseguí una gratis en https://aistudio.google.com/apikey"
        )

    history.append({"role": "user", "text": user_text})
    while len(history) > MAX_TURNS * 2:
        history.pop(0)

    contents = []
    for h in history:
        contents.append({
            "role": h["role"],
            "parts": [{"text": h["text"]}],
        })

    payload = {
        "system_instruction": {
            "parts": [{"text": system_prompt(subject)}]
        },
        "contents": contents,
        "generationConfig": {
            "temperature": 0.7,
            "maxOutputTokens": 2048,
        },
    }

    last_err = u""
    for model in MODELS:
        url = (
            "https://generativelanguage.googleapis.com/v1beta/models/%s"
            ":generateContent?key=%s" % (model, key)
        )
        try:
            code, raw = http_post_json(url, payload)
            text, err = parse_reply(raw)
            if code >= 200 and code < 300 and text:
                history.append({"role": "model", "text": text})
                while len(history) > MAX_TURNS * 2:
                    history.pop(0)
                return text, model, None
            if code in (401, 403):
                if history and history[-1]["role"] == "user":
                    history.pop()
                return None, None, u"Clave inválida o sin permiso. Revisá config.txt."
            if code == 429:
                if history and history[-1]["role"] == "user":
                    history.pop()
                return None, None, u"Límite gratis de Gemini. Probá en unos minutos."
            last_err = u"HTTP %s %s [%s]" % (code, err or u"", model)
            if code in (400, 404):
                continue
        except Exception as e:
            last_err = u"%s [%s]" % (e, model)

    if history and history[-1]["role"] == "user":
        history.pop()
    return None, None, last_err or (
        u"No se pudo contactar a Gemini. Revisá Internet y LEEME.txt."
    )


class NexoApp(object):
    def __init__(self, root):
        self.root = root
        self.history = []
        self.subject = SUBJECTS[0]
        self.busy = False

        root.title(u"NEXO AI · Linux Lite")
        root.geometry("960x680")
        root.minsize(720, 520)
        root.configure(bg=C_BG)

        # Header lavanda
        top = tk.Frame(root, bg=C_HEADER, padx=14, pady=12)
        top.pack(fill="x")
        title_row = tk.Frame(top, bg=C_HEADER)
        title_row.pack(fill="x")
        tk.Label(
            title_row, text=u"NEXO AI", fg=C_TEAL, bg=C_HEADER,
            font=ui_font(18, True)
        ).pack(side="left")
        tk.Label(
            title_row, text=u"  Linux Lite", fg=C_LAV, bg=C_HEADER,
            font=ui_font(12, True)
        ).pack(side="left", pady=(4, 0))
        tk.Label(
            top,
            text=u"Tutor de estudio · Puppy / Linux · clave Gemini en config.txt",
            fg=C_MUTED, bg=C_HEADER, font=ui_font(9)
        ).pack(anchor="w", pady=(4, 0))

        # Materias — pills suaves
        chips_wrap = tk.Frame(root, bg=C_BG, padx=12, pady=8)
        chips_wrap.pack(fill="x")
        tk.Label(
            chips_wrap, text=u"Materia", fg=C_MUTED, bg=C_BG, font=ui_font(8)
        ).pack(anchor="w", pady=(0, 4))
        chips = tk.Frame(chips_wrap, bg=C_BG)
        chips.pack(fill="x")
        self.chip_btns = {}
        for name in SUBJECTS:
            b = tk.Button(
                chips, text=name, relief="flat", bd=0,
                command=lambda n=name: self.set_subject(n),
                bg=C_CHIP, fg=C_CHIP_FG, activebackground=C_CHIP_ON,
                activeforeground=C_CHIP_ON_FG,
                font=ui_font(9), padx=10, pady=4,
                highlightthickness=0,
            )
            b.pack(side="left", padx=3, pady=2)
            self.chip_btns[name] = b
        self.set_subject(self.subject)

        # Área de chat — “tarjeta” blanca
        chat_frame = tk.Frame(root, bg=C_BORDER, padx=1, pady=1)
        chat_frame.pack(fill="both", expand=True, padx=12, pady=(0, 8))
        inner = tk.Frame(chat_frame, bg=C_CARD)
        inner.pack(fill="both", expand=True)
        self.chat = ScrolledText.ScrolledText(
            inner, wrap="word", bg=C_CARD, fg=C_TEXT,
            insertbackground=C_TEXT, font=ui_font(10),
            relief="flat", state="disabled", padx=12, pady=10,
            highlightthickness=0, bd=0,
        )
        self.chat.pack(fill="both", expand=True)
        self.chat.tag_config("user", foreground=C_CORAL, font=ui_font(10, True))
        self.chat.tag_config("bot", foreground=C_TEAL, font=ui_font(10, True))
        self.chat.tag_config("sys", foreground=C_LAV, font=ui_font(10, True))
        self.chat.tag_config("body", foreground=C_TEXT, font=ui_font(10))

        # Pie: input + botones
        bottom = tk.Frame(root, bg=C_BG, padx=12, pady=4)
        bottom.pack(fill="x")
        input_wrap = tk.Frame(bottom, bg=C_BORDER, padx=1, pady=1)
        input_wrap.pack(fill="x")
        self.input = tk.Text(
            input_wrap, height=3, bg=C_INPUT_BG, fg=C_TEXT,
            insertbackground=C_TEXT, font=ui_font(10), relief="flat",
            padx=8, pady=6, highlightthickness=0, bd=0,
        )
        self.input.pack(fill="x")
        self.input.bind("<Control-Return>", lambda e: self.send())

        btns = tk.Frame(bottom, bg=C_BG)
        btns.pack(fill="x", pady=(8, 2))
        tk.Button(
            btns, text=u"Enviar", command=self.send,
            bg=C_BTN_TEAL, fg="#FFFFFF", activebackground=C_TEAL,
            font=ui_font(10, True), relief="flat", padx=14, pady=5,
            highlightthickness=0,
        ).pack(side="left", padx=(0, 6))
        tk.Button(
            btns, text=u"Modo examen", command=self.exam,
            bg=C_BTN_CORAL, fg="#FFFFFF", activebackground=C_CORAL,
            font=ui_font(10, True), relief="flat", padx=12, pady=5,
            highlightthickness=0,
        ).pack(side="left", padx=(0, 6))
        tk.Button(
            btns, text=u"Limpiar", command=self.clear,
            bg=C_BTN_SOFT, fg=C_LAV, activebackground=C_HEADER,
            font=ui_font(9), relief="flat", padx=10, pady=5,
            highlightthickness=0,
        ).pack(side="left", padx=(0, 6))
        tk.Button(
            btns, text=u"Releer clave", command=self.refresh_status,
            bg=C_BTN_SOFT, fg=C_LAV, activebackground=C_HEADER,
            font=ui_font(9), relief="flat", padx=10, pady=5,
            highlightthickness=0,
        ).pack(side="left")

        self.status = tk.Label(
            bottom, text=u"", anchor="w", bg=C_BG, fg=C_MUTED,
            font=ui_font(8)
        )
        self.status.pack(fill="x", pady=(6, 8))

        self.append_sys(
            u"Hola. Soy NEXO Linux Lite.\n"
            u"Elegí una materia, escribí tu duda y tocá Enviar.\n"
            u"Necesitás Internet y una clave gratis de Gemini en config.txt."
        )
        self.refresh_status()

    def set_subject(self, name):
        self.subject = name
        for n, b in self.chip_btns.items():
            if n == name:
                b.configure(bg=C_CHIP_ON, fg=C_CHIP_ON_FG)
            else:
                b.configure(bg=C_CHIP, fg=C_CHIP_FG)
        self.refresh_status()

    def refresh_status(self):
        key = read_api_key()
        if not key or len(key) < 10:
            self.status.configure(
                text=u"Falta la clave en config.txt (aistudio.google.com/apikey) · Materia: %s"
                % self.subject,
                fg=C_ERR,
            )
        else:
            self.status.configure(
                text=u"Clave detectada · Materia: %s · Modelo: flash free · %s"
                % (self.subject, VERSION),
                fg=C_OK,
            )

    def _write(self, who, text, tag):
        self.chat.configure(state="normal")
        self.chat.insert("end", who + u"\n", tag)
        self.chat.insert("end", text + u"\n\n", "body")
        self.chat.configure(state="disabled")
        self.chat.see("end")

    def append_user(self, text):
        self._write(u"Vos", text, "user")

    def append_bot(self, who, text):
        self._write(who, text, "bot")

    def append_sys(self, text):
        self._write(u"NEXO", text, "sys")

    def clear(self):
        self.history = []
        self.chat.configure(state="normal")
        self.chat.delete("1.0", "end")
        self.chat.configure(state="disabled")
        self.append_sys(u"Chat limpio. Elegí materia y preguntá de nuevo.")

    def _get_input(self):
        text = self.input.get("1.0", "end").strip()
        self.input.delete("1.0", "end")
        return text

    def send(self):
        if self.busy:
            return
        text = self._get_input()
        if not text:
            return
        self.append_user(text)
        self.busy = True
        self.status.configure(text=u"Pensando…", fg=C_MUTED)
        self.root.update_idletasks()
        try:
            reply, model, err = call_gemini(self.history, self.subject, text)
            if reply:
                self.append_bot(u"NEXO (%s)" % model, reply)
            else:
                self.append_sys(u"Error: %s" % err)
        except Exception:
            self.append_sys(u"Error interno:\n%s" % traceback.format_exc())
        self.busy = False
        self.refresh_status()

    def exam(self):
        if self.busy:
            return
        tema = self.input.get("1.0", "end").strip()
        if not tema:
            self.append_sys(
                u"Para Modo examen: escribí un tema (ej: ecuaciones) y tocá Modo examen."
            )
            return
        self.input.delete("1.0", "end")
        prompt = (
            u"Armá un mini ensayo de práctica (modo examen) sobre: %s.\n"
            u"Dadme exactamente 3 preguntas claras, numeradas 1-2-3, acordes a la materia %s.\n"
            u"Después de las 3 preguntas, en una sección aparte llamada RESPUESTAS, "
            u"poné las respuestas breves comentadas.\n"
            u"Nivel secundario. Español rioplatense."
        ) % (tema, self.subject)
        self.append_user(u"[Modo examen] %s" % tema)
        self.busy = True
        self.status.configure(text=u"Armando 3 preguntas…", fg=C_MUTED)
        self.root.update_idletasks()
        try:
            reply, model, err = call_gemini(self.history, self.subject, prompt)
            if reply:
                self.append_bot(u"NEXO examen (%s)" % model, reply)
            else:
                self.append_sys(u"Error: %s" % err)
        except Exception:
            self.append_sys(u"Error interno:\n%s" % traceback.format_exc())
        self.busy = False
        self.refresh_status()


def main():
    root = tk.Tk()
    NexoApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
