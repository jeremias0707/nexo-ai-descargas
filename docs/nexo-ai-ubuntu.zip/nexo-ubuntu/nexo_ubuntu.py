# -*- coding: utf-8 -*-
"""NEXO AI Ubuntu 3.0.3 — tutor para Ubuntu (~2 GB). Python 3 + Tkinter + Grok (xAI)."""
from __future__ import print_function

import json
import os
import re
import sys
import threading
import traceback
import uuid
from datetime import datetime

try:
    import urllib.request as urllib_request
    import urllib.error as urllib_error
except ImportError:
    import urllib2 as urllib_request
    urllib_error = urllib_request

try:
    import tkinter as tk
    from tkinter import messagebox, filedialog, scrolledtext as ScrolledText, simpledialog
except ImportError:
    print(
        "Falta Tkinter.\n"
        "En Ubuntu:\n"
        "  sudo apt update\n"
        "  sudo apt install python3-tk\n"
        "Después:  python3 nexo_ubuntu.py"
    )
    sys.exit(1)

VERSION = "3.0.3-ubuntu"
# Modelos xAI (rápido / no-reasoning primero).
MODELS = [
    "grok-4.3",
    "grok-4.20-0309-non-reasoning",
    "grok-4-1-fast-non-reasoning",
]
API_URL = "https://api.x.ai/v1/chat/completions"
MAX_TURNS = 18
NOTE_CAP = 70000
NOTE_PROMPT_CAP = 12000
SUBJECTS = [
    u"Matemática",
    u"Historia",
    u"Biología",
    u"Lengua",
    u"Química",
    u"Física",
    u"Otras",
]

APP_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(APP_DIR, "config.txt")
PREFS_PATH = os.path.join(APP_DIR, "preferencias.txt")
DATA_DIR = os.path.join(APP_DIR, "data")
PLAN_PATH = os.path.join(DATA_DIR, "plan.json")
CHATS_DIR = os.path.join(DATA_DIR, "chats")
CHATS_INDEX = os.path.join(CHATS_DIR, "index.json")

# Paleta NEXO Ubuntu — oscura + celeste
C_BG = "#0F1724"
C_SIDE = "#152033"
C_HEADER = "#1A2740"
C_CARD = "#1E2D45"
C_CHIP = "#243552"
C_CHIP_ON = "#38BDF8"
C_CHIP_ON_FG = "#0B1220"
C_CHIP_FG = "#A8C0D8"
C_ACCENT = "#38BDF8"
C_ACCENT_DIM = "#0EA5E9"
C_USER = "#F472B6"
C_BOT = "#38BDF8"
C_SYS = "#A78BFA"
C_TEXT = "#E8EEF6"
C_MUTED = "#8BA0B8"
C_BTN = "#0EA5E9"
C_BTN_EXAM = "#F43F5E"
C_BTN_SOFT = "#2A3B55"
C_BTN_PLAN = "#6366F1"
C_BTN_CHAT = "#14B8A6"
C_INPUT_BG = "#152033"
C_OK = "#34D399"
C_ERR = "#FB7185"
C_BORDER = "#2A3F5C"
C_WARN = "#FBBF24"
C_LIST_SEL = "#0EA5E9"


def ui_font(size=10, bold=False):
    weight = "bold" if bold else "normal"
    for family in ("DejaVu Sans", "Ubuntu", "Liberation Sans", "FreeSans", "TkDefaultFont"):
        try:
            return (family, size, weight) if bold else (family, size)
        except Exception:
            continue
    return ("TkDefaultFont", size, weight) if bold else ("TkDefaultFont", size)


def ensure_dirs():
    for d in (DATA_DIR, CHATS_DIR):
        try:
            if not os.path.isdir(d):
                os.makedirs(d)
        except Exception:
            pass


def slugify(name):
    s = (name or u"otras").strip().lower()
    for a, b in (
        (u"á", "a"), (u"é", "e"), (u"í", "i"), (u"ó", "o"), (u"ú", "u"),
        (u"ñ", "n"), (u"ü", "u"),
    ):
        s = s.replace(a, b)
    s = re.sub(r"[^a-z0-9]+", "_", s)
    return (s.strip("_") or "otras")[:48]


def new_chat_id():
    return uuid.uuid4().hex[:12]


def chat_file(cid):
    return os.path.join(CHATS_DIR, "%s.json" % cid)


def read_api_key():
    if not os.path.isfile(CONFIG_PATH):
        return ""
    try:
        f = open(CONFIG_PATH, "r")
        try:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                for prefix in ("GROK_API_KEY=", "XAI_API_KEY="):
                    if line.startswith(prefix):
                        return line[len(prefix):].strip().strip('"').strip("'")
        finally:
            f.close()
    except Exception:
        return ""
    return ""


def load_prefs():
    prefs = {"subject": SUBJECTS[0]}
    if not os.path.isfile(PREFS_PATH):
        return prefs
    try:
        f = open(PREFS_PATH, "r")
        try:
            for line in f:
                line = line.strip()
                if line.startswith("subject="):
                    val = line[len("subject="):].strip()
                    if val:
                        prefs["subject"] = val
        finally:
            f.close()
    except Exception:
        pass
    return prefs


def save_prefs(subject):
    try:
        f = open(PREFS_PATH, "w")
        try:
            f.write("subject=%s\n" % subject)
        finally:
            f.close()
    except Exception:
        pass


# --- Plan de exámenes ---

def load_plan():
    ensure_dirs()
    if not os.path.isfile(PLAN_PATH):
        return []
    try:
        f = open(PLAN_PATH, "r")
        try:
            data = json.load(f)
        finally:
            f.close()
        if not isinstance(data, list):
            return []
        out = []
        for item in data:
            if not isinstance(item, dict):
                continue
            date = str(item.get("date", "")).strip()
            topic = str(item.get("topic", "")).strip()
            subject = str(item.get("subject", "")).strip() or u"Otras"
            if date and topic:
                out.append({"date": date, "topic": topic, "subject": subject})
        return out
    except Exception:
        return []


def save_plan(items):
    ensure_dirs()
    try:
        f = open(PLAN_PATH, "w")
        try:
            json.dump(items, f, ensure_ascii=False, indent=2)
        finally:
            f.close()
    except Exception:
        pass


def sort_plan(items):
    def key(it):
        try:
            return datetime.strptime(it["date"][:10], "%Y-%m-%d")
        except Exception:
            return datetime.max
    return sorted(items, key=key)


# --- Chats (sistema multi-chat) ---

def empty_chat(subject=None):
    prefs = load_prefs()
    subj = subject or prefs.get("subject", SUBJECTS[0])
    return {
        "id": new_chat_id(),
        "title": u"Chat nuevo",
        "subject": subj,
        "updated": datetime.now().strftime("%Y-%m-%dT%H:%M:%S"),
        "history": [],
        "note_name": u"",
        "note_text": u"",
    }


def load_chats_index():
    ensure_dirs()
    if not os.path.isfile(CHATS_INDEX):
        return {"active": None, "chats": []}
    try:
        f = open(CHATS_INDEX, "r")
        try:
            data = json.load(f)
        finally:
            f.close()
        if not isinstance(data, dict):
            return {"active": None, "chats": []}
        chats = data.get("chats") or []
        if not isinstance(chats, list):
            chats = []
        clean = []
        for c in chats:
            if isinstance(c, dict) and c.get("id"):
                clean.append({
                    "id": str(c["id"]),
                    "title": str(c.get("title") or u"Chat nuevo"),
                    "subject": str(c.get("subject") or SUBJECTS[0]),
                    "updated": str(c.get("updated") or ""),
                })
        return {"active": data.get("active"), "chats": clean}
    except Exception:
        return {"active": None, "chats": []}


def save_chats_index(index):
    ensure_dirs()
    try:
        f = open(CHATS_INDEX, "w")
        try:
            json.dump(index, f, ensure_ascii=False, indent=2)
        finally:
            f.close()
    except Exception:
        pass


def load_chat(cid):
    path = chat_file(cid)
    if not os.path.isfile(path):
        return None
    try:
        f = open(path, "r")
        try:
            data = json.load(f)
        finally:
            f.close()
        if not isinstance(data, dict):
            return None
        hist = []
        for item in data.get("history") or []:
            if isinstance(item, dict) and item.get("role") and "content" in item:
                hist.append({"role": item["role"], "content": item["content"]})
        while len(hist) > MAX_TURNS * 2:
            hist.pop(0)
        return {
            "id": str(data.get("id") or cid),
            "title": str(data.get("title") or u"Chat nuevo"),
            "subject": str(data.get("subject") or SUBJECTS[0]),
            "updated": str(data.get("updated") or ""),
            "history": hist,
            "note_name": str(data.get("note_name") or u""),
            "note_text": str(data.get("note_text") or u""),
        }
    except Exception:
        return None


def save_chat(chat):
    ensure_dirs()
    clipped = list(chat.get("history") or [])
    while len(clipped) > MAX_TURNS * 2:
        clipped.pop(0)
    note_text = chat.get("note_text") or u""
    if len(note_text) > NOTE_CAP:
        note_text = note_text[:NOTE_CAP]
    payload = {
        "id": chat["id"],
        "title": chat.get("title") or u"Chat nuevo",
        "subject": chat.get("subject") or SUBJECTS[0],
        "updated": chat.get("updated") or datetime.now().strftime("%Y-%m-%dT%H:%M:%S"),
        "history": clipped,
        "note_name": chat.get("note_name") or u"",
        "note_text": note_text,
    }
    try:
        f = open(chat_file(chat["id"]), "w")
        try:
            json.dump(payload, f, ensure_ascii=False, indent=0)
        finally:
            f.close()
    except Exception:
        pass
    return payload


def delete_chat_file(cid):
    path = chat_file(cid)
    try:
        if os.path.isfile(path):
            os.remove(path)
    except Exception:
        pass


def auto_title_from_text(text):
    t = (text or u"").strip().replace("\n", " ")
    for prefix in (u"[Modo examen] ", u"[Repaso] "):
        if t.startswith(prefix):
            t = t[len(prefix):]
    t = t.strip()
    if not t:
        return u"Chat nuevo"
    if len(t) > 36:
        return t[:33] + u"…"
    return t


# --- Apuntes / PDF ---

def extract_pdf_text(path):
    try:
        from pypdf import PdfReader
    except ImportError:
        try:
            from PyPDF2 import PdfReader
        except ImportError:
            return None, (
                u"Para leer PDF instalá:  sudo apt install python3-pypdf\n"
                u"(o: pip3 install --user pypdf). Mientras, usá .txt o .md."
            )
    try:
        reader = PdfReader(path)
        chunks = []
        total = 0
        for page in reader.pages:
            try:
                t = page.extract_text() or ""
            except Exception:
                t = ""
            if not t:
                continue
            if total + len(t) > NOTE_CAP:
                t = t[: max(0, NOTE_CAP - total)]
                chunks.append(t)
                break
            chunks.append(t)
            total += len(t)
        text = u"\n".join(chunks).strip()
        if not text:
            return None, u"El PDF no trajo texto legible (puede ser escaneado)."
        return text, None
    except Exception as e:
        return None, u"No pude leer el PDF: %s" % e


def read_note_file(path):
    lower = path.lower()
    if lower.endswith(".pdf"):
        return extract_pdf_text(path)
    try:
        f = open(path, "rb")
        try:
            raw = f.read(NOTE_CAP + 4096)
        finally:
            f.close()
        try:
            text = raw.decode("utf-8")
        except UnicodeDecodeError:
            text = raw.decode("latin-1", "replace")
        if len(text) > NOTE_CAP:
            text = text[:NOTE_CAP]
        text = text.strip()
        if not text:
            return None, u"El archivo está vacío."
        return text, None
    except Exception as e:
        return None, u"No pude abrir el archivo: %s" % e


# --- Grok API ---

def system_prompt(subject, note_snippet=None):
    base = (
        u"Sos NEXO, un tutor de estudio para estudiantes de secundaria/preparatoria "
        u"en Argentina/Uruguay. Hablá en español rioplatense natural (vos, dale, mirá), "
        u"claro y cercano, sin ser infantil. Materia actual: %s. "
        u"Explicá paso a paso. Si no estás seguro, decilo. No inventes datos. "
        u"No des respuestas solo para copiar en un examen: ayudá a entender. "
        u"Sé breve si alcanza, y más detallado si el tema lo pide. "
        u"Esta es NEXO AI Ubuntu (Grok / xAI): chats, historial, apuntes y plan de exámenes."
    ) % subject
    if note_snippet:
        clipped = note_snippet[:NOTE_PROMPT_CAP]
        base += (
            u"\n\nEl estudiante cargó estos apuntes (usálos si ayudan, no los copies enteros):\n"
            u"---\n%s\n---" % clipped
        )
    return base


def http_post_json(url, payload, api_key):
    data = json.dumps(payload)
    if isinstance(data, str) and not isinstance(data, bytes):
        data = data.encode("utf-8")
    req = urllib_request.Request(url, data=data)
    req.add_header("Content-Type", "application/json")
    req.add_header("Authorization", "Bearer %s" % api_key)
    try:
        resp = urllib_request.urlopen(req, timeout=90)
        raw = resp.read()
        code = getattr(resp, "code", 200)
        resp.close()
        return code, raw
    except urllib_error.HTTPError as e:
        raw = e.read()
        return e.code, raw


def parse_grok_reply(raw):
    if isinstance(raw, bytes):
        try:
            raw = raw.decode("utf-8")
        except Exception:
            raw = raw.decode("latin-1", "replace")
    obj = json.loads(raw)
    if "error" in obj:
        err = obj["error"]
        if isinstance(err, dict):
            return None, err.get("message", str(err))
        return None, str(err)
    choices = obj.get("choices") or []
    if not choices:
        return None, u"Respuesta vacía del modelo."
    msg = choices[0].get("message") or {}
    content = msg.get("content")
    if content:
        return content, None
    return None, u"Sin texto (finish=%s)" % choices[0].get("finish_reason")


def call_grok(history, subject, user_text, note_snippet=None):
    key = read_api_key()
    if not key or len(key) < 10:
        return None, None, (
            u"Falta GROK_API_KEY (o XAI_API_KEY) en config.txt. "
            u"Conseguí una en https://console.x.ai/ — la API de xAI es de pago."
        )

    history.append({"role": "user", "content": user_text})
    while len(history) > MAX_TURNS * 2:
        history.pop(0)

    messages = [{"role": "system", "content": system_prompt(subject, note_snippet)}]
    for h in history:
        role = h["role"]
        if role == "model":
            role = "assistant"
        messages.append({"role": role, "content": h["content"]})

    last_err = u""
    for model in MODELS:
        payload = {
            "model": model,
            "messages": messages,
            "temperature": 0.7,
            "max_tokens": 2048,
        }
        if model == "grok-4.3":
            payload["reasoning_effort"] = "none"
        try:
            code, raw = http_post_json(API_URL, payload, key)
            text, err = parse_grok_reply(raw)
            if 200 <= code < 300 and text:
                history.append({"role": "assistant", "content": text})
                while len(history) > MAX_TURNS * 2:
                    history.pop(0)
                return text, model, None
            if code in (401, 403):
                if history and history[-1]["role"] == "user":
                    history.pop()
                return None, None, (
                    u"Clave inválida o sin permiso (HTTP %s). "
                    u"Revisá config.txt y https://console.x.ai/"
                ) % code
            if code == 429:
                if history and history[-1]["role"] == "user":
                    history.pop()
                return None, None, (
                    u"Límite de uso / rate limit (429). "
                    u"Esperá un rato o revisá el crédito en console.x.ai."
                )
            last_err = u"HTTP %s %s [%s]" % (code, err or u"", model)
            if code in (400, 404):
                continue
        except Exception as e:
            last_err = u"%s [%s]" % (e, model)

    if history and history[-1]["role"] == "user":
        history.pop()
    return None, None, last_err or (
        u"No se pudo contactar a Grok (xAI). Revisá Internet y LEEME.txt."
    )


def last_user_topic(history):
    for h in reversed(history):
        if h.get("role") == "user":
            t = (h.get("content") or "").strip()
            if t.startswith(u"[Modo examen]") or t.startswith(u"[Repaso]"):
                continue
            if len(t) > 8:
                return t[:200]
    return u""


class NexoApp(object):
    def __init__(self, root):
        self.root = root
        self.busy = False
        self.last_model = u""
        self.status = None  # never refresh_status before Label exists
        self.chip_btns = {}
        self.chat_ids = []  # parallel to listbox order
        self.suppress_chat_select = False

        ensure_dirs()
        prefs = load_prefs()
        self.plan = sort_plan(load_plan())

        # Load or create chats
        self.index = load_chats_index()
        self.chat = None
        if self.index["chats"]:
            active = self.index.get("active")
            ids = [c["id"] for c in self.index["chats"]]
            if active not in ids:
                active = ids[0]
            loaded = load_chat(active)
            if loaded is None:
                loaded = empty_chat(prefs.get("subject"))
                loaded["id"] = active
                save_chat(loaded)
            self.chat = loaded
            self.index["active"] = active
        else:
            self.chat = empty_chat(prefs.get("subject"))
            self._register_chat(self.chat)
        self.subject = self.chat.get("subject") or prefs.get("subject", SUBJECTS[0])
        self.history = list(self.chat.get("history") or [])
        self.note_text = self.chat.get("note_text") or u""
        self.note_name = self.chat.get("note_name") or u""

        root.title(u"NEXO AI · Ubuntu")
        root.geometry("1140x740")
        root.minsize(880, 580)
        root.configure(bg=C_BG)

        self._build_header()
        body = tk.Frame(root, bg=C_BG)
        body.pack(fill="both", expand=True)
        self._build_sidebar(body)
        self._build_main(body)

        # Status AFTER widgets — init-order fix
        self.status = tk.Label(
            root, text=u"", anchor="w", bg=C_BG, fg=C_MUTED,
            font=ui_font(8), padx=14, pady=8,
        )
        self.status.pack(fill="x", side="bottom")

        self._paint_chips()
        self._refresh_chat_list(select_id=self.chat["id"])
        self.refresh_plan_list()
        self._reload_chat_view()
        self._update_note_label()
        self.refresh_status()
        if not self.history:
            self.append_sys(
                u"Hola. Soy NEXO AI Ubuntu %s.\n"
                u"Chats a la izquierda · materias · apuntes · plan de exámenes.\n"
                u"Necesitás Internet y GROK_API_KEY en config.txt (console.x.ai — de pago).\n"
                u"Atajo: Ctrl+Enter envía."
                % VERSION
            )

    # ----- UI build -----

    def _build_header(self):
        top = tk.Frame(self.root, bg=C_HEADER, padx=16, pady=12)
        top.pack(fill="x")
        row = tk.Frame(top, bg=C_HEADER)
        row.pack(fill="x")
        tk.Label(
            row, text=u"NEXO AI", fg=C_ACCENT, bg=C_HEADER,
            font=ui_font(18, True)
        ).pack(side="left")
        tk.Label(
            row, text=u"  · Ubuntu", fg=C_TEXT, bg=C_HEADER,
            font=ui_font(12, True)
        ).pack(side="left", pady=(3, 0))
        tk.Label(
            row, text=u"  %s" % VERSION, fg=C_MUTED, bg=C_HEADER,
            font=ui_font(9)
        ).pack(side="right", pady=(4, 0))
        tk.Label(
            top,
            text=u"Grok (xAI) · chats · historial · apuntes · plan de exámenes · pensado para ~2 GB RAM",
            fg=C_MUTED, bg=C_HEADER, font=ui_font(8)
        ).pack(anchor="w", pady=(4, 0))

    def _build_sidebar(self, parent):
        side = tk.Frame(parent, bg=C_SIDE, width=236)
        side.pack(side="left", fill="y")
        side.pack_propagate(False)
        inner = tk.Frame(side, bg=C_SIDE, padx=10, pady=10)
        inner.pack(fill="both", expand=True)

        # Chats
        tk.Label(
            inner, text=u"CHATS", fg=C_MUTED, bg=C_SIDE, font=ui_font(8, True)
        ).pack(anchor="w", pady=(0, 4))
        chat_btns = tk.Frame(inner, bg=C_SIDE)
        chat_btns.pack(fill="x", pady=(0, 4))
        tk.Button(
            chat_btns, text=u"+ Nuevo", command=self.new_chat,
            bg=C_BTN_CHAT, fg="#06201C", relief="flat", font=ui_font(8, True),
            padx=6, pady=3, highlightthickness=0,
        ).pack(side="left", padx=(0, 3))
        tk.Button(
            chat_btns, text=u"Renombrar", command=self.rename_chat,
            bg=C_BTN_SOFT, fg=C_CHIP_FG, relief="flat", font=ui_font(8),
            padx=5, pady=3, highlightthickness=0,
        ).pack(side="left", padx=(0, 3))
        tk.Button(
            chat_btns, text=u"Borrar", command=self.delete_chat,
            bg=C_BTN_SOFT, fg=C_ERR, relief="flat", font=ui_font(8),
            padx=5, pady=3, highlightthickness=0,
        ).pack(side="left")

        self.chat_list = tk.Listbox(
            inner, height=7, bg=C_CARD, fg=C_TEXT, font=ui_font(8),
            relief="flat", highlightthickness=1, highlightbackground=C_BORDER,
            selectbackground=C_LIST_SEL, selectforeground=C_CHIP_ON_FG,
            activestyle="none", exportselection=False,
        )
        self.chat_list.pack(fill="x", pady=(0, 8))
        self.chat_list.bind("<<ListboxSelect>>", self._on_chat_select)

        tk.Frame(inner, bg=C_BORDER, height=1).pack(fill="x", pady=(0, 8))

        # Materias
        tk.Label(
            inner, text=u"MATERIAS", fg=C_MUTED, bg=C_SIDE, font=ui_font(8, True)
        ).pack(anchor="w", pady=(0, 4))
        for name in SUBJECTS:
            b = tk.Button(
                inner, text=name, relief="flat", bd=0, anchor="w",
                command=lambda n=name: self.set_subject(n),
                bg=C_CHIP, fg=C_CHIP_FG, activebackground=C_CHIP_ON,
                activeforeground=C_CHIP_ON_FG,
                font=ui_font(9), padx=10, pady=4,
                highlightthickness=0,
            )
            b.pack(fill="x", pady=1)
            self.chip_btns[name] = b

        tk.Label(
            inner, text=u"Otra materia", fg=C_MUTED, bg=C_SIDE, font=ui_font(8)
        ).pack(anchor="w", pady=(8, 2))
        self.custom_subj = tk.Entry(
            inner, bg=C_INPUT_BG, fg=C_TEXT, font=ui_font(9),
            relief="flat", insertbackground=C_TEXT,
            highlightthickness=1, highlightbackground=C_BORDER,
        )
        self.custom_subj.pack(fill="x", pady=(0, 4))
        tk.Button(
            inner, text=u"Usar materia", command=self.use_custom_subject,
            bg=C_BTN_SOFT, fg=C_ACCENT, relief="flat", font=ui_font(8, True),
            padx=6, pady=3, highlightthickness=0,
        ).pack(anchor="w")

        tk.Frame(inner, bg=C_BORDER, height=1).pack(fill="x", pady=10)

        # Plan
        tk.Label(
            inner, text=u"PLAN DE EXÁMENES", fg=C_MUTED, bg=C_SIDE,
            font=ui_font(8, True)
        ).pack(anchor="w", pady=(0, 4))
        self.plan_list = tk.Listbox(
            inner, height=5, bg=C_CARD, fg=C_TEXT, font=ui_font(8),
            relief="flat", highlightthickness=1, highlightbackground=C_BORDER,
            selectbackground=C_BTN_PLAN, activestyle="none",
            exportselection=False,
        )
        self.plan_list.pack(fill="both", expand=True)
        plan_btns = tk.Frame(inner, bg=C_SIDE)
        plan_btns.pack(fill="x", pady=(6, 0))
        tk.Button(
            plan_btns, text=u"Plan +", command=self.add_exam_dialog,
            bg=C_BTN_PLAN, fg="#FFFFFF", relief="flat", font=ui_font(8, True),
            padx=6, pady=3, highlightthickness=0,
        ).pack(side="left", padx=(0, 4))
        tk.Button(
            plan_btns, text=u"Quitar", command=self.remove_selected_exam,
            bg=C_BTN_SOFT, fg=C_CHIP_FG, relief="flat", font=ui_font(8),
            padx=6, pady=3, highlightthickness=0,
        ).pack(side="left")

        tk.Label(
            inner, text=VERSION, fg=C_MUTED, bg=C_SIDE, font=ui_font(7)
        ).pack(anchor="w", pady=(10, 0))

    def _build_main(self, parent):
        main = tk.Frame(parent, bg=C_BG, padx=12, pady=8)
        main.pack(side="left", fill="both", expand=True)

        note_bar = tk.Frame(main, bg=C_BG)
        note_bar.pack(fill="x", pady=(0, 6))
        tk.Button(
            note_bar, text=u"Cargar apunte", command=self.load_note,
            bg=C_BTN_SOFT, fg=C_ACCENT, relief="flat", font=ui_font(9, True),
            padx=8, pady=4, highlightthickness=0,
        ).pack(side="left", padx=(0, 4))
        tk.Button(
            note_bar, text=u"Pegar apunte", command=self.paste_note_dialog,
            bg=C_BTN_SOFT, fg=C_ACCENT, relief="flat", font=ui_font(9, True),
            padx=8, pady=4, highlightthickness=0,
        ).pack(side="left", padx=(0, 4))
        tk.Button(
            note_bar, text=u"Quitar apunte", command=self.clear_note,
            bg=C_BTN_SOFT, fg=C_MUTED, relief="flat", font=ui_font(8),
            padx=6, pady=4, highlightthickness=0,
        ).pack(side="left", padx=(0, 8))
        self.note_label = tk.Label(
            note_bar, text=u"Sin apunte cargado", anchor="w",
            bg=C_BG, fg=C_MUTED, font=ui_font(8)
        )
        self.note_label.pack(side="left", fill="x", expand=True)

        self.chat_title_lbl = tk.Label(
            main, text=u"", anchor="w", bg=C_BG, fg=C_TEXT, font=ui_font(11, True)
        )
        self.chat_title_lbl.pack(fill="x", pady=(0, 4))

        chat_frame = tk.Frame(main, bg=C_BORDER, padx=1, pady=1)
        chat_frame.pack(fill="both", expand=True)
        inner = tk.Frame(chat_frame, bg=C_CARD)
        inner.pack(fill="both", expand=True)
        self.chat_view = ScrolledText.ScrolledText(
            inner, wrap="word", bg=C_CARD, fg=C_TEXT,
            insertbackground=C_TEXT, font=ui_font(10),
            relief="flat", state="disabled", padx=12, pady=10,
            highlightthickness=0, bd=0,
        )
        self.chat_view.pack(fill="both", expand=True)
        self.chat_view.tag_config("user", foreground=C_USER, font=ui_font(10, True))
        self.chat_view.tag_config("bot", foreground=C_BOT, font=ui_font(10, True))
        self.chat_view.tag_config("sys", foreground=C_SYS, font=ui_font(10, True))
        self.chat_view.tag_config("body", foreground=C_TEXT, font=ui_font(10))

        bottom = tk.Frame(main, bg=C_BG, pady=6)
        bottom.pack(fill="x")
        input_wrap = tk.Frame(bottom, bg=C_BORDER, padx=1, pady=1)
        input_wrap.pack(fill="x")
        self.input = tk.Text(
            input_wrap, height=3, bg=C_INPUT_BG, fg=C_TEXT,
            insertbackground=C_TEXT, font=ui_font(10), relief="flat",
            padx=8, pady=6, highlightthickness=0, bd=0,
        )
        self.input.pack(fill="x")
        self.input.bind("<Control-Return>", lambda e: self.send())

        btns = tk.Frame(bottom, bg=C_BG)
        btns.pack(fill="x", pady=(8, 0))
        tk.Button(
            btns, text=u"Enviar", command=self.send,
            bg=C_BTN, fg="#FFFFFF", activebackground=C_ACCENT_DIM,
            font=ui_font(10, True), relief="flat", padx=14, pady=5,
            highlightthickness=0,
        ).pack(side="left", padx=(0, 6))
        tk.Button(
            btns, text=u"Modo examen", command=self.exam,
            bg=C_BTN_EXAM, fg="#FFFFFF", activebackground="#E11D48",
            font=ui_font(10, True), relief="flat", padx=12, pady=5,
            highlightthickness=0,
        ).pack(side="left", padx=(0, 6))
        tk.Button(
            btns, text=u"Repaso", command=self.repaso,
            bg=C_BTN_PLAN, fg="#FFFFFF", activebackground="#4F46E5",
            font=ui_font(10, True), relief="flat", padx=12, pady=5,
            highlightthickness=0,
        ).pack(side="left", padx=(0, 6))
        tk.Button(
            btns, text=u"Limpiar chat", command=self.clear,
            bg=C_BTN_SOFT, fg=C_CHIP_FG, relief="flat", font=ui_font(9),
            padx=10, pady=5, highlightthickness=0,
        ).pack(side="left", padx=(0, 6))
        tk.Button(
            btns, text=u"Releer clave", command=self.refresh_status,
            bg=C_BTN_SOFT, fg=C_CHIP_FG, relief="flat", font=ui_font(9),
            padx=10, pady=5, highlightthickness=0,
        ).pack(side="left")

    # ----- Persist helpers -----

    def _register_chat(self, chat):
        meta = {
            "id": chat["id"],
            "title": chat.get("title") or u"Chat nuevo",
            "subject": chat.get("subject") or SUBJECTS[0],
            "updated": chat.get("updated") or datetime.now().strftime("%Y-%m-%dT%H:%M:%S"),
        }
        others = [c for c in self.index["chats"] if c["id"] != chat["id"]]
        self.index["chats"] = [meta] + others
        self.index["active"] = chat["id"]
        save_chat(chat)
        save_chats_index(self.index)

    def _persist_active(self):
        if not self.chat:
            return
        self.chat["history"] = list(self.history)
        self.chat["subject"] = self.subject
        self.chat["note_text"] = self.note_text
        self.chat["note_name"] = self.note_name
        self.chat["updated"] = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
        save_chat(self.chat)
        # update index meta
        found = False
        for c in self.index["chats"]:
            if c["id"] == self.chat["id"]:
                c["title"] = self.chat.get("title") or u"Chat nuevo"
                c["subject"] = self.subject
                c["updated"] = self.chat["updated"]
                found = True
                break
        if not found:
            self.index["chats"].insert(0, {
                "id": self.chat["id"],
                "title": self.chat.get("title") or u"Chat nuevo",
                "subject": self.subject,
                "updated": self.chat["updated"],
            })
        # bump active to top
        self.index["chats"] = (
            [c for c in self.index["chats"] if c["id"] == self.chat["id"]]
            + [c for c in self.index["chats"] if c["id"] != self.chat["id"]]
        )
        self.index["active"] = self.chat["id"]
        save_chats_index(self.index)

    def _refresh_chat_list(self, select_id=None):
        self.suppress_chat_select = True
        self.chat_list.delete(0, "end")
        self.chat_ids = []
        for c in self.index["chats"]:
            title = c.get("title") or u"Chat nuevo"
            subj = c.get("subject") or ""
            label = u"%s · %s" % (title, subj) if subj else title
            if len(label) > 42:
                label = label[:39] + u"…"
            self.chat_list.insert("end", label)
            self.chat_ids.append(c["id"])
        if select_id and select_id in self.chat_ids:
            idx = self.chat_ids.index(select_id)
            self.chat_list.selection_clear(0, "end")
            self.chat_list.selection_set(idx)
            self.chat_list.see(idx)
        self.suppress_chat_select = False
        self._update_chat_title()

    def _update_chat_title(self):
        if not self.chat:
            return
        t = self.chat.get("title") or u"Chat nuevo"
        self.chat_title_lbl.configure(
            text=u"%s  ·  %s" % (t, self.subject)
        )

    def _on_chat_select(self, event=None):
        if self.suppress_chat_select or self.busy:
            return
        sel = self.chat_list.curselection()
        if not sel:
            return
        idx = sel[0]
        if idx < 0 or idx >= len(self.chat_ids):
            return
        cid = self.chat_ids[idx]
        if self.chat and cid == self.chat["id"]:
            return
        self.switch_chat(cid)

    def new_chat(self):
        if self.busy:
            return
        self._persist_active()
        chat = empty_chat(self.subject)
        self.chat = chat
        self.history = []
        self.note_text = u""
        self.note_name = u""
        self._register_chat(chat)
        self._refresh_chat_list(select_id=chat["id"])
        self._paint_chips()
        self._reload_chat_view()
        self._update_note_label()
        self.refresh_status()
        self.append_sys(u"Chat nuevo. Elegí materia y preguntá.")

    def rename_chat(self):
        if not self.chat:
            return
        current = self.chat.get("title") or u"Chat nuevo"
        name = simpledialog.askstring(
            u"Renombrar chat", u"Nuevo nombre:",
            initialvalue=current, parent=self.root,
        )
        if not name:
            return
        name = name.strip()
        if not name:
            return
        if len(name) > 48:
            name = name[:48]
        self.chat["title"] = name
        self._persist_active()
        self._refresh_chat_list(select_id=self.chat["id"])

    def delete_chat(self):
        if self.busy or not self.chat:
            return
        if len(self.index["chats"]) <= 1:
            # clear current instead of deleting last
            if messagebox.askyesno(
                u"Borrar chat",
                u"Es el único chat. ¿Lo vacío?",
            ):
                self.clear()
            return
        title = self.chat.get("title") or u"Chat nuevo"
        if not messagebox.askyesno(u"Borrar chat", u"¿Borrar «%s»?" % title):
            return
        cid = self.chat["id"]
        delete_chat_file(cid)
        self.index["chats"] = [c for c in self.index["chats"] if c["id"] != cid]
        next_id = self.index["chats"][0]["id"]
        self.index["active"] = next_id
        save_chats_index(self.index)
        loaded = load_chat(next_id) or empty_chat(self.subject)
        if loaded["id"] != next_id:
            loaded["id"] = next_id
        self.chat = loaded
        self.subject = loaded.get("subject") or SUBJECTS[0]
        self.history = list(loaded.get("history") or [])
        self.note_text = loaded.get("note_text") or u""
        self.note_name = loaded.get("note_name") or u""
        save_prefs(self.subject)
        self._paint_chips()
        self._refresh_chat_list(select_id=next_id)
        self._reload_chat_view()
        self._update_note_label()
        self.refresh_status()

    def switch_chat(self, cid):
        if self.busy:
            self._refresh_chat_list(select_id=self.chat["id"] if self.chat else None)
            return
        if self.chat and self.chat["id"] == cid:
            return
        self._persist_active()
        loaded = load_chat(cid)
        if loaded is None:
            messagebox.showwarning(u"Chat", u"No encontré ese chat.")
            self._refresh_chat_list(select_id=self.chat["id"] if self.chat else None)
            return
        self.chat = loaded
        self.subject = loaded.get("subject") or SUBJECTS[0]
        self.history = list(loaded.get("history") or [])
        self.note_text = loaded.get("note_text") or u""
        self.note_name = loaded.get("note_name") or u""
        self.index["active"] = cid
        save_chats_index(self.index)
        save_prefs(self.subject)
        self._paint_chips()
        self._refresh_chat_list(select_id=cid)
        self._reload_chat_view()
        self._update_note_label()
        self.refresh_status()

    # ----- Subjects -----

    def _paint_chips(self):
        for n, b in self.chip_btns.items():
            if n == self.subject:
                b.configure(bg=C_CHIP_ON, fg=C_CHIP_ON_FG)
            else:
                b.configure(bg=C_CHIP, fg=C_CHIP_FG)

    def use_custom_subject(self):
        name = self.custom_subj.get().strip()
        if not name:
            self.append_sys(u"Escribí el nombre de la materia personalizada.")
            return
        if len(name) > 40:
            name = name[:40]
        self.set_subject(name)

    def set_subject(self, name):
        if self.busy:
            return
        self.subject = name
        save_prefs(name)
        if self.chat:
            self.chat["subject"] = name
            self._persist_active()
            self._refresh_chat_list(select_id=self.chat["id"])
        self._paint_chips()
        self._update_chat_title()
        self.refresh_status()

    # ----- Chat view -----

    def _reload_chat_view(self):
        self.chat_view.configure(state="normal")
        self.chat_view.delete("1.0", "end")
        self.chat_view.configure(state="disabled")
        for h in self.history:
            role = h.get("role")
            content = h.get("content") or u""
            if role == "user":
                self._write(u"Vos", content, "user")
            elif role in ("assistant", "model"):
                self._write(u"NEXO", content, "bot")
        self._update_chat_title()

    def _write(self, who, text, tag):
        self.chat_view.configure(state="normal")
        self.chat_view.insert("end", who + u"\n", tag)
        self.chat_view.insert("end", text + u"\n\n", "body")
        self.chat_view.configure(state="disabled")
        self.chat_view.see("end")

    def append_user(self, text):
        self._write(u"Vos", text, "user")

    def append_bot(self, who, text):
        self._write(who, text, "bot")

    def append_sys(self, text):
        self._write(u"NEXO", text, "sys")

    def clear(self):
        if self.busy:
            return
        self.history = []
        if self.chat:
            self.chat["history"] = []
            self.chat["title"] = u"Chat nuevo"
            self._persist_active()
            self._refresh_chat_list(select_id=self.chat["id"])
        self.chat_view.configure(state="normal")
        self.chat_view.delete("1.0", "end")
        self.chat_view.configure(state="disabled")
        self.append_sys(u"Chat limpio. Preguntá de nuevo.")
        self._update_chat_title()

    def refresh_status(self):
        if self.status is None:
            return
        key = read_api_key()
        note_bit = u""
        if self.note_name:
            note_bit = u" · Apunte: %s" % self.note_name
        elif self.note_text:
            note_bit = u" · Apunte pegado (%d chars)" % len(self.note_text)
        model_hint = self.last_model or u"grok-4.3"
        nchats = len(self.index.get("chats") or [])
        if not key or len(key) < 10:
            self.status.configure(
                text=u"Falta GROK_API_KEY en config.txt (console.x.ai) · %s · %d chats · %s%s"
                % (self.subject, nchats, VERSION, note_bit),
                fg=C_ERR,
            )
        else:
            self.status.configure(
                text=u"Clave OK · %s · %s · %d chats · %s%s"
                % (self.subject, model_hint, nchats, VERSION, note_bit),
                fg=C_OK,
            )

    # ----- Plan -----

    def refresh_plan_list(self):
        self.plan_list.delete(0, "end")
        today = datetime.now().date()
        shown = 0
        for item in self.plan:
            try:
                d = datetime.strptime(item["date"][:10], "%Y-%m-%d").date()
                delta = (d - today).days
                if delta < -1:
                    continue
                when = d.strftime("%d/%m")
                if delta == 0:
                    label = u"HOY %s · %s" % (when, item["topic"])
                elif delta == 1:
                    label = u"Mañana %s · %s" % (when, item["topic"])
                else:
                    label = u"%s · %s · %s" % (when, item.get("subject", ""), item["topic"])
            except Exception:
                label = u"%s · %s" % (item.get("date", "?"), item.get("topic", "?"))
            self.plan_list.insert("end", label)
            shown += 1
            if shown >= 12:
                break
        if shown == 0:
            self.plan_list.insert("end", u"(sin exámenes)")

    def add_exam_dialog(self):
        win = tk.Toplevel(self.root)
        win.title(u"Agregar examen")
        win.configure(bg=C_BG)
        win.geometry("380x240")
        win.transient(self.root)
        win.grab_set()

        tk.Label(win, text=u"Fecha (AAAA-MM-DD)", bg=C_BG, fg=C_MUTED,
                 font=ui_font(8)).pack(anchor="w", padx=12, pady=(12, 2))
        date_e = tk.Entry(
            win, font=ui_font(10), relief="flat", bg=C_INPUT_BG, fg=C_TEXT,
            insertbackground=C_TEXT, highlightthickness=1, highlightbackground=C_BORDER,
        )
        date_e.pack(fill="x", padx=12)
        date_e.insert(0, datetime.now().strftime("%Y-%m-%d"))

        tk.Label(win, text=u"Tema / unidad", bg=C_BG, fg=C_MUTED,
                 font=ui_font(8)).pack(anchor="w", padx=12, pady=(8, 2))
        topic_e = tk.Entry(
            win, font=ui_font(10), relief="flat", bg=C_INPUT_BG, fg=C_TEXT,
            insertbackground=C_TEXT, highlightthickness=1, highlightbackground=C_BORDER,
        )
        topic_e.pack(fill="x", padx=12)

        tk.Label(win, text=u"Materia (opcional)", bg=C_BG, fg=C_MUTED,
                 font=ui_font(8)).pack(anchor="w", padx=12, pady=(8, 2))
        subj_e = tk.Entry(
            win, font=ui_font(10), relief="flat", bg=C_INPUT_BG, fg=C_TEXT,
            insertbackground=C_TEXT, highlightthickness=1, highlightbackground=C_BORDER,
        )
        subj_e.pack(fill="x", padx=12)
        subj_e.insert(0, self.subject)

        def save():
            date = date_e.get().strip()
            topic = topic_e.get().strip()
            subject = subj_e.get().strip() or self.subject
            try:
                datetime.strptime(date[:10], "%Y-%m-%d")
            except Exception:
                messagebox.showerror(u"Fecha", u"Usá el formato AAAA-MM-DD (ej: 2026-11-15).")
                return
            if not topic:
                messagebox.showerror(u"Tema", u"Escribí el tema del examen.")
                return
            self.plan.append({"date": date[:10], "topic": topic, "subject": subject})
            self.plan = sort_plan(self.plan)
            save_plan(self.plan)
            self.refresh_plan_list()
            win.destroy()

        tk.Button(
            win, text=u"Guardar", command=save,
            bg=C_BTN_PLAN, fg="#FFFFFF", relief="flat", font=ui_font(10, True),
            padx=12, pady=5, highlightthickness=0,
        ).pack(pady=14)

    def remove_selected_exam(self):
        sel = self.plan_list.curselection()
        if not sel:
            return
        idx = sel[0]
        today = datetime.now().date()
        visible = []
        for i, item in enumerate(self.plan):
            try:
                d = datetime.strptime(item["date"][:10], "%Y-%m-%d").date()
                if (d - today).days < -1:
                    continue
            except Exception:
                pass
            visible.append(i)
            if len(visible) >= 12:
                break
        if idx >= len(visible):
            return
        real = visible[idx]
        self.plan.pop(real)
        save_plan(self.plan)
        self.refresh_plan_list()

    # ----- Apuntes -----

    def _update_note_label(self):
        if self.note_name:
            n = len(self.note_text or u"")
            if n >= NOTE_CAP:
                self.note_label.configure(
                    text=u"Apunte: %s (recortado a %d chars)" % (self.note_name, NOTE_CAP),
                    fg=C_WARN,
                )
            else:
                self.note_label.configure(
                    text=u"Apunte: %s (%d chars)" % (self.note_name, n),
                    fg=C_ACCENT,
                )
        elif self.note_text:
            self.note_label.configure(
                text=u"Apunte pegado (%d chars)" % len(self.note_text),
                fg=C_ACCENT,
            )
        else:
            self.note_label.configure(text=u"Sin apunte cargado", fg=C_MUTED)

    def load_note(self):
        path = filedialog.askopenfilename(
            title=u"Elegí un apunte",
            filetypes=[
                (u"Texto / Markdown", "*.txt *.md"),
                (u"PDF (opcional)", "*.pdf"),
                (u"Todos", "*.*"),
            ],
        )
        if not path:
            return
        text, err = read_note_file(path)
        if err and text is None:
            messagebox.showwarning(u"Apunte", err)
            return
        if err and text is not None:
            messagebox.showwarning(u"Apunte", err)
        if text is None:
            return
        self.note_text = text
        self.note_name = os.path.basename(path)
        self._update_note_label()
        self._persist_active()
        self.refresh_status()
        self.append_sys(
            u"Apunte cargado: %s. Lo uso como contexto cuando preguntes."
            % self.note_name
        )

    def paste_note_dialog(self):
        win = tk.Toplevel(self.root)
        win.title(u"Pegar apunte")
        win.configure(bg=C_BG)
        win.geometry("520x400")
        win.transient(self.root)
        win.grab_set()
        tk.Label(
            win, text=u"Pegá el texto del apunte (máx ~%d caracteres):" % NOTE_CAP,
            bg=C_BG, fg=C_MUTED, font=ui_font(9),
        ).pack(anchor="w", padx=10, pady=(10, 4))
        box = ScrolledText.ScrolledText(
            win, wrap="word", font=ui_font(10), bg=C_CARD, fg=C_TEXT,
            insertbackground=C_TEXT, relief="flat", padx=8, pady=8,
        )
        box.pack(fill="both", expand=True, padx=10, pady=4)

        def save():
            text = box.get("1.0", "end").strip()
            if not text:
                messagebox.showerror(u"Apunte", u"No hay texto.")
                return
            if len(text) > NOTE_CAP:
                text = text[:NOTE_CAP]
            self.note_text = text
            self.note_name = u"pegado"
            self._update_note_label()
            self._persist_active()
            self.refresh_status()
            self.append_sys(u"Apunte pegado listo (%d caracteres)." % len(text))
            win.destroy()

        tk.Button(
            win, text=u"Usar apunte", command=save,
            bg=C_BTN, fg="#FFFFFF", relief="flat", font=ui_font(10, True),
            padx=12, pady=5, highlightthickness=0,
        ).pack(pady=10)

    def clear_note(self):
        self.note_text = u""
        self.note_name = u""
        self._update_note_label()
        self._persist_active()
        self.refresh_status()
        self.append_sys(u"Apunte quitado.")

    # ----- Send / exam / repaso -----

    def _get_input(self):
        text = self.input.get("1.0", "end").strip()
        self.input.delete("1.0", "end")
        return text

    def _maybe_auto_title(self, user_display):
        if not self.chat:
            return
        title = self.chat.get("title") or u"Chat nuevo"
        if title == u"Chat nuevo" or not title.strip():
            self.chat["title"] = auto_title_from_text(user_display)
            self._persist_active()
            self._refresh_chat_list(select_id=self.chat["id"])

    def _run_async(self, user_display, prompt_for_api, status_msg):
        if self.busy:
            return
        self.append_user(user_display)
        self._maybe_auto_title(user_display)
        self.busy = True
        if self.status is not None:
            self.status.configure(text=status_msg, fg=C_MUTED)
        note = self.note_text or None
        subject = self.subject
        # work on a copy of history; merge back on success
        hist_snapshot = list(self.history)

        def worker():
            reply, model, err = None, None, None
            hist = list(hist_snapshot)
            try:
                reply, model, err = call_grok(hist, subject, prompt_for_api, note)
            except Exception:
                err = u"Error interno:\n%s" % traceback.format_exc()

            def finish():
                if reply:
                    self.history = hist
                    self.last_model = model or u""
                    self.append_bot(u"NEXO (%s)" % model, reply)
                    self._persist_active()
                    self._refresh_chat_list(select_id=self.chat["id"] if self.chat else None)
                else:
                    self.append_sys(u"Error: %s" % err)
                self.busy = False
                self.refresh_status()

            self.root.after(0, finish)

        threading.Thread(target=worker, daemon=True).start()

    def send(self):
        if self.busy:
            return
        text = self._get_input()
        if not text:
            return
        self._run_async(text, text, u"Pensando con Grok…")

    def exam(self):
        if self.busy:
            return
        tema = self.input.get("1.0", "end").strip()
        if not tema:
            self.append_sys(
                u"Para Modo examen: escribí un tema (ej: ecuaciones) y tocá Modo examen."
            )
            return
        self.input.delete("1.0", "end")
        prompt = (
            u"Armá un mini ensayo de práctica (modo examen) sobre: %s.\n"
            u"Dadme exactamente 5 preguntas claras, numeradas 1-2-3-4-5, "
            u"acordes a la materia %s.\n"
            u"Después de las 5 preguntas, en una sección aparte llamada RESPUESTAS, "
            u"poné las respuestas breves comentadas.\n"
            u"Nivel secundario. Español rioplatense."
        ) % (tema, self.subject)
        self._run_async(
            u"[Modo examen] %s" % tema,
            prompt,
            u"Armando 5 preguntas…",
        )

    def repaso(self):
        if self.busy:
            return
        tema = last_user_topic(self.history)
        if not tema:
            typed = self.input.get("1.0", "end").strip()
            if typed:
                tema = typed
                self.input.delete("1.0", "end")
            else:
                self.append_sys(
                    u"Repaso: primero chateá un tema, o escribilo en el cuadro y tocá Repaso."
                )
                return
        prompt = (
            u"Armá un repaso adaptativo corto sobre este tema (o el último que hablamos):\n"
            u"%s\n\n"
            u"Materia: %s.\n"
            u"Dadme 3 preguntas rápidas (sin opciones múltiples), numeradas, "
            u"y después las RESPUESTAS breves en una sección aparte.\n"
            u"Nivel secundario. Español rioplatense. Sé concreto."
        ) % (tema, self.subject)
        self._run_async(
            u"[Repaso] %s" % (tema[:80] + (u"…" if len(tema) > 80 else u"")),
            prompt,
            u"Armando repaso…",
        )


def main():
    ensure_dirs()
    root = tk.Tk()
    NexoApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
