# -*- coding: utf-8 -*-
"""NEXO AI Ubuntu — tutor de estudio (Python 3 + Tkinter), optimizado ~2 GB RAM."""
from __future__ import print_function

import json
import os
import re
import sys
import traceback
from datetime import datetime

try:
    import urllib.request as urllib_request
    import urllib.error as urllib_error
except ImportError:
    import urllib2 as urllib_request
    urllib_error = urllib_request

try:
    import tkinter as tk
    from tkinter import messagebox, filedialog, scrolledtext as ScrolledText
except ImportError:
    print(
        "Falta Tkinter.\n"
        "En Ubuntu:\n"
        "  sudo apt update\n"
        "  sudo apt install python3-tk\n"
        "Después:  python3 nexo_ubuntu.py"
    )
    sys.exit(1)

VERSION = "3.0.2-ubuntu"
MODELS = [
    "gemini-flash-latest",
    "gemini-3.8-flash",
    "gemini-3.5-flash-lite",
    "gemini-3.6-flash",
]
MAX_TURNS = 16
NOTE_CAP = 70000
SUBJECTS = [
    u"Matemática",
    u"Historia",
    u"Biología",
    u"Lengua",
    u"Química",
    u"Física",
    u"Otras",
]

APP_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(APP_DIR, "config.txt")
DATA_DIR = os.path.join(APP_DIR, "data")
PLAN_PATH = os.path.join(DATA_DIR, "plan.json")

# Paleta Ubuntu: header oscuro + papel + acentos teal/celeste
C_BG = "#F4F1EC"
C_HEADER = "#1A3A3A"
C_HEADER_FG = "#E8F6F4"
C_ACCENT = "#4EC9BF"
C_SIDEBAR = "#E8F0EE"
C_CARD = "#FFFFFF"
C_CHIP = "#D6EDE9"
C_CHIP_ON = "#3A9B94"
C_CHIP_ON_FG = "#FFFFFF"
C_CHIP_FG = "#2F5F5A"
C_TEAL = "#2E8B84"
C_CORAL = "#D96B7A"
C_LAV = "#6B5FA0"
C_TEXT = "#2C3338"
C_MUTED = "#6A757C"
C_BTN_TEAL = "#3A9B94"
C_BTN_CORAL = "#E07A8A"
C_BTN_SOFT = "#DDE8E5"
C_BTN_PLAN = "#5B8FBF"
C_INPUT_BG = "#FFFBF7"
C_OK = "#3D9B6E"
C_ERR = "#C45C5C"
C_BORDER = "#D5D0C8"
C_WARN = "#C9A227"


def ui_font(size=10, bold=False):
    weight = "bold" if bold else "normal"
    for family in ("DejaVu Sans", "Ubuntu", "Liberation Sans", "FreeSans", "TkDefaultFont"):
        try:
            return (family, size, weight) if bold else (family, size)
        except Exception:
            continue
    return ("TkDefaultFont", size, weight) if bold else ("TkDefaultFont", size)


def ensure_data_dir():
    try:
        if not os.path.isdir(DATA_DIR):
            os.makedirs(DATA_DIR)
    except Exception:
        pass


def slugify(name):
    s = (name or u"otras").strip().lower()
    repl = {
        u"á": "a", u"é": "e", u"í": "i", u"ó": "o", u"ú": "u",
        u"ñ": "n", u"ü": "u",
    }
    for a, b in repl.items():
        s = s.replace(a, b)
    s = re.sub(r"[^a-z0-9]+", "_", s)
    s = s.strip("_") or "otras"
    return s[:48]


def hist_path(subject):
    return os.path.join(DATA_DIR, "historial_%s.json" % slugify(subject))


def read_api_key():
    if not os.path.isfile(CONFIG_PATH):
        return ""
    try:
        with open(CONFIG_PATH, "r") as f:
            for line in f:
                line = line.strip()
                if line.startswith("GEMINI_API_KEY="):
                    return line[len("GEMINI_API_KEY="):].strip()
    except Exception:
        return ""
    return ""


def load_history(subject):
    ensure_data_dir()
    path = hist_path(subject)
    if not os.path.isfile(path):
        return []
    try:
        with open(path, "r") as f:
            data = json.load(f)
        if isinstance(data, list):
            out = []
            for item in data:
                if isinstance(item, dict) and "role" in item and "text" in item:
                    out.append({"role": item["role"], "text": item["text"]})
            while len(out) > MAX_TURNS * 2:
                out.pop(0)
            return out
    except Exception:
        return []
    return []


def save_history(subject, history):
    ensure_data_dir()
    path = hist_path(subject)
    clipped = list(history)
    while len(clipped) > MAX_TURNS * 2:
        clipped.pop(0)
    try:
        with open(path, "w") as f:
            json.dump(clipped, f, ensure_ascii=False, indent=0)
    except Exception:
        pass


def clear_history_file(subject):
    path = hist_path(subject)
    try:
        if os.path.isfile(path):
            os.remove(path)
    except Exception:
        pass


def load_plan():
    ensure_data_dir()
    if not os.path.isfile(PLAN_PATH):
        return []
    try:
        with open(PLAN_PATH, "r") as f:
            data = json.load(f)
        if isinstance(data, list):
            out = []
            for item in data:
                if not isinstance(item, dict):
                    continue
                date = str(item.get("date", "")).strip()
                topic = str(item.get("topic", "")).strip()
                subject = str(item.get("subject", "")).strip() or u"Otras"
                if date and topic:
                    out.append({"date": date, "topic": topic, "subject": subject})
            return out
    except Exception:
        return []
    return []


def save_plan(items):
    ensure_data_dir()
    try:
        with open(PLAN_PATH, "w") as f:
            json.dump(items, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def sort_plan(items):
    def key(it):
        try:
            return datetime.strptime(it["date"][:10], "%Y-%m-%d")
        except Exception:
            return datetime.max
    return sorted(items, key=key)


def extract_pdf_text(path):
    """Best-effort PDF text. Uses pypdf if installed; else returns None + hint."""
    try:
        from pypdf import PdfReader
    except ImportError:
        try:
            from PyPDF2 import PdfReader
        except ImportError:
            return None, (
                u"Para leer PDF instalá:  sudo apt install python3-pypdf\n"
                u"(o: pip3 install --user pypdf). Mientras, usá .txt o .md."
            )
    try:
        reader = PdfReader(path)
        chunks = []
        total = 0
        for page in reader.pages:
            try:
                t = page.extract_text() or ""
            except Exception:
                t = ""
            if not t:
                continue
            if total + len(t) > NOTE_CAP:
                t = t[: max(0, NOTE_CAP - total)]
                chunks.append(t)
                break
            chunks.append(t)
            total += len(t)
        text = u"\n".join(chunks).strip()
        if not text:
            return None, u"El PDF no trajo texto legible (puede ser escaneado)."
        return text, None
    except Exception as e:
        return None, u"No pude leer el PDF: %s" % e


def read_note_file(path):
    lower = path.lower()
    if lower.endswith(".pdf"):
        return extract_pdf_text(path)
    try:
        with open(path, "rb") as f:
            raw = f.read(NOTE_CAP + 4096)
        try:
            text = raw.decode("utf-8")
        except UnicodeDecodeError:
            text = raw.decode("latin-1", "replace")
        if len(text) > NOTE_CAP:
            text = text[:NOTE_CAP]
        text = text.strip()
        if not text:
            return None, u"El archivo está vacío."
        return text, None
    except Exception as e:
        return None, u"No pude abrir el archivo: %s" % e


def system_prompt(subject, note_snippet=None):
    base = (
        u"Sos NEXO, un tutor de estudio para estudiantes de secundaria/preparatoria "
        u"en Argentina/Uruguay. Hablá en español rioplatense natural (vos, dale, mirá), "
        u"claro y cercano, sin ser infantil. Materia actual: %s. "
        u"Explicá paso a paso. Si no estás seguro, decilo. No inventes datos. "
        u"No des respuestas solo para copiar en un examen: ayudá a entender. "
        u"Sé breve si alcanza, y más detallado si el tema lo pide. "
        u"Esta es NEXO AI Ubuntu (ligera, local): historial por materia, apuntes y plan de exámenes."
    ) % subject
    if note_snippet:
        clipped = note_snippet[:12000]
        base += (
            u"\n\nEl estudiante cargó estos apuntes (usálos si ayudan, no los copies enteros):\n"
            u"---\n%s\n---" % clipped
        )
    return base


def http_post_json(url, payload):
    data = json.dumps(payload)
    if isinstance(data, str) and not isinstance(data, bytes):
        data = data.encode("utf-8")
    req = urllib_request.Request(url, data=data)
    req.add_header("Content-Type", "application/json; charset=utf-8")
    try:
        resp = urllib_request.urlopen(req, timeout=60)
        raw = resp.read()
        code = getattr(resp, "code", 200)
        resp.close()
        return code, raw
    except urllib_error.HTTPError as e:
        raw = e.read()
        return e.code, raw


def parse_reply(raw):
    if isinstance(raw, bytes):
        try:
            raw = raw.decode("utf-8")
        except Exception:
            raw = raw.decode("latin-1", "replace")
    obj = json.loads(raw)
    if "error" in obj:
        msg = obj["error"]
        if isinstance(msg, dict):
            return None, msg.get("message", str(msg))
        return None, str(msg)
    cands = obj.get("candidates") or []
    if not cands:
        return None, u"Respuesta vacía del modelo."
    parts = (cands[0].get("content") or {}).get("parts") or []
    texts = []
    for p in parts:
        if "text" in p:
            texts.append(p["text"])
    if texts:
        return u"\n".join(texts), None
    return None, u"Sin texto (finish=%s)" % cands[0].get("finishReason")


def call_gemini(history, subject, user_text, note_snippet=None):
    key = read_api_key()
    if not key or len(key) < 10:
        return None, None, (
            u"Falta GEMINI_API_KEY en config.txt. "
            u"Conseguí una gratis en https://aistudio.google.com/apikey"
        )

    history.append({"role": "user", "text": user_text})
    while len(history) > MAX_TURNS * 2:
        history.pop(0)

    contents = []
    for h in history:
        contents.append({
            "role": h["role"],
            "parts": [{"text": h["text"]}],
        })

    payload = {
        "system_instruction": {
            "parts": [{"text": system_prompt(subject, note_snippet)}]
        },
        "contents": contents,
        "generationConfig": {
            "temperature": 0.7,
            "maxOutputTokens": 2048,
        },
    }

    last_err = u""
    for model in MODELS:
        url = (
            "https://generativelanguage.googleapis.com/v1beta/models/%s"
            ":generateContent?key=%s" % (model, key)
        )
        try:
            code, raw = http_post_json(url, payload)
            text, err = parse_reply(raw)
            if code >= 200 and code < 300 and text:
                history.append({"role": "model", "text": text})
                while len(history) > MAX_TURNS * 2:
                    history.pop(0)
                return text, model, None
            if code in (401, 403):
                if history and history[-1]["role"] == "user":
                    history.pop()
                return None, None, u"Clave inválida o sin permiso. Revisá config.txt."
            if code == 429:
                if history and history[-1]["role"] == "user":
                    history.pop()
                return None, None, u"Límite gratis de Gemini. Probá en unos minutos."
            last_err = u"HTTP %s %s [%s]" % (code, err or u"", model)
            if code in (400, 404):
                continue
        except Exception as e:
            last_err = u"%s [%s]" % (e, model)

    if history and history[-1]["role"] == "user":
        history.pop()
    return None, None, last_err or (
        u"No se pudo contactar a Gemini. Revisá Internet y LEEME.txt."
    )


class NexoApp(object):
    def __init__(self, root):
        self.root = root
        self.subject = SUBJECTS[0]
        self.history = []
        self.busy = False
        self.note_text = u""
        self.note_name = u""
        self.plan = []
        self.chip_btns = {}
        self.status = None  # NEVER call refresh_status before this is a Label

        ensure_data_dir()
        self.plan = sort_plan(load_plan())
        self.history = load_history(self.subject)

        root.title(u"NEXO AI · Ubuntu")
        root.geometry("1100x720")
        root.minsize(860, 560)
        root.configure(bg=C_BG)

        self._build_header()
        body = tk.Frame(root, bg=C_BG)
        body.pack(fill="both", expand=True)
        self._build_sidebar(body)
        self._build_main(body)
        self._build_status_bar()

        self._paint_chips()
        self._reload_chat_from_history()
        self.refresh_plan_list()
        self.refresh_status()
        if not self.history:
            self.append_sys(
                u"Hola. Soy NEXO AI Ubuntu.\n"
                u"Elegí materia a la izquierda, cargá apuntes si querés, "
                u"y preguntame. El historial se guarda por materia.\n"
                u"Clave Gemini gratis en config.txt · ~2 GB RAM OK."
            )

    def _build_header(self):
        top = tk.Frame(self.root, bg=C_HEADER, padx=16, pady=12)
        top.pack(fill="x")
        row = tk.Frame(top, bg=C_HEADER)
        row.pack(fill="x")
        tk.Label(
            row, text=u"NEXO AI", fg=C_ACCENT, bg=C_HEADER,
            font=ui_font(20, True)
        ).pack(side="left")
        tk.Label(
            row, text=u"  · Ubuntu", fg=C_HEADER_FG, bg=C_HEADER,
            font=ui_font(13, True)
        ).pack(side="left", pady=(4, 0))
        tk.Label(
            row, text=u"  %s" % VERSION, fg="#8AABB0", bg=C_HEADER,
            font=ui_font(9)
        ).pack(side="right", pady=(6, 0))
        tk.Label(
            top,
            text=u"Tutor local · historial · apuntes · plan de exámenes · Gemini free",
            fg="#A8C8C4", bg=C_HEADER, font=ui_font(9)
        ).pack(anchor="w", pady=(4, 0))

    def _build_sidebar(self, parent):
        side = tk.Frame(parent, bg=C_SIDEBAR, width=230, padx=10, pady=10)
        side.pack(side="left", fill="y")
        side.pack_propagate(False)

        tk.Label(
            side, text=u"MATERIAS", fg=C_MUTED, bg=C_SIDEBAR, font=ui_font(8, True)
        ).pack(anchor="w", pady=(0, 6))

        for name in SUBJECTS:
            b = tk.Button(
                side, text=name, relief="flat", bd=0, anchor="w",
                command=lambda n=name: self.set_subject(n),
                bg=C_CHIP, fg=C_CHIP_FG, activebackground=C_CHIP_ON,
                activeforeground=C_CHIP_ON_FG,
                font=ui_font(10), padx=10, pady=5,
                highlightthickness=0,
            )
            b.pack(fill="x", pady=2)
            self.chip_btns[name] = b

        tk.Label(
            side, text=u"Otra materia", fg=C_MUTED, bg=C_SIDEBAR, font=ui_font(8)
        ).pack(anchor="w", pady=(10, 2))
        self.custom_subj = tk.Entry(
            side, bg=C_INPUT_BG, fg=C_TEXT, font=ui_font(9),
            relief="flat", highlightthickness=1, highlightbackground=C_BORDER,
        )
        self.custom_subj.pack(fill="x", pady=(0, 4))
        tk.Button(
            side, text=u"Usar materia", command=self.use_custom_subject,
            bg=C_BTN_SOFT, fg=C_TEAL, relief="flat", font=ui_font(8, True),
            padx=6, pady=3, highlightthickness=0,
        ).pack(anchor="w")

        tk.Frame(side, bg=C_BORDER, height=1).pack(fill="x", pady=12)

        tk.Label(
            side, text=u"PRÓXIMOS EXÁMENES", fg=C_MUTED, bg=C_SIDEBAR,
            font=ui_font(8, True)
        ).pack(anchor="w", pady=(0, 4))
        self.plan_list = tk.Listbox(
            side, height=8, bg=C_CARD, fg=C_TEXT, font=ui_font(8),
            relief="flat", highlightthickness=1, highlightbackground=C_BORDER,
            selectbackground=C_CHIP_ON, activestyle="none",
        )
        self.plan_list.pack(fill="both", expand=True)

        plan_btns = tk.Frame(side, bg=C_SIDEBAR)
        plan_btns.pack(fill="x", pady=(6, 0))
        tk.Button(
            plan_btns, text=u"+ Examen", command=self.add_exam_dialog,
            bg=C_BTN_PLAN, fg="#FFFFFF", relief="flat", font=ui_font(8, True),
            padx=6, pady=3, highlightthickness=0,
        ).pack(side="left", padx=(0, 4))
        tk.Button(
            plan_btns, text=u"Quitar", command=self.remove_selected_exam,
            bg=C_BTN_SOFT, fg=C_LAV, relief="flat", font=ui_font(8),
            padx=6, pady=3, highlightthickness=0,
        ).pack(side="left")

    def _build_main(self, parent):
        main = tk.Frame(parent, bg=C_BG, padx=12, pady=8)
        main.pack(side="left", fill="both", expand=True)

        note_bar = tk.Frame(main, bg=C_BG)
        note_bar.pack(fill="x", pady=(0, 6))
        tk.Button(
            note_bar, text=u"Cargar apunte", command=self.load_note,
            bg=C_BTN_SOFT, fg=C_TEAL, relief="flat", font=ui_font(9, True),
            padx=8, pady=4, highlightthickness=0,
        ).pack(side="left", padx=(0, 4))
        tk.Button(
            note_bar, text=u"Pegar apunte", command=self.paste_note_dialog,
            bg=C_BTN_SOFT, fg=C_TEAL, relief="flat", font=ui_font(9, True),
            padx=8, pady=4, highlightthickness=0,
        ).pack(side="left", padx=(0, 4))
        tk.Button(
            note_bar, text=u"Quitar apunte", command=self.clear_note,
            bg=C_BTN_SOFT, fg=C_MUTED, relief="flat", font=ui_font(8),
            padx=6, pady=4, highlightthickness=0,
        ).pack(side="left", padx=(0, 8))
        self.note_label = tk.Label(
            note_bar, text=u"Sin apunte cargado", anchor="w",
            bg=C_BG, fg=C_MUTED, font=ui_font(8)
        )
        self.note_label.pack(side="left", fill="x", expand=True)

        chat_frame = tk.Frame(main, bg=C_BORDER, padx=1, pady=1)
        chat_frame.pack(fill="both", expand=True)
        inner = tk.Frame(chat_frame, bg=C_CARD)
        inner.pack(fill="both", expand=True)
        self.chat = ScrolledText.ScrolledText(
            inner, wrap="word", bg=C_CARD, fg=C_TEXT,
            insertbackground=C_TEXT, font=ui_font(11),
            relief="flat", state="disabled", padx=14, pady=12,
            highlightthickness=0, bd=0,
        )
        self.chat.pack(fill="both", expand=True)
        self.chat.tag_config("user", foreground=C_CORAL, font=ui_font(11, True))
        self.chat.tag_config("bot", foreground=C_TEAL, font=ui_font(11, True))
        self.chat.tag_config("sys", foreground=C_LAV, font=ui_font(11, True))
        self.chat.tag_config("body", foreground=C_TEXT, font=ui_font(11))

        bottom = tk.Frame(main, bg=C_BG, pady=6)
        bottom.pack(fill="x")
        input_wrap = tk.Frame(bottom, bg=C_BORDER, padx=1, pady=1)
        input_wrap.pack(fill="x")
        self.input = tk.Text(
            input_wrap, height=3, bg=C_INPUT_BG, fg=C_TEXT,
            insertbackground=C_TEXT, font=ui_font(11), relief="flat",
            padx=8, pady=6, highlightthickness=0, bd=0,
        )
        self.input.pack(fill="x")
        self.input.bind("<Control-Return>", lambda e: self.send())

        btns = tk.Frame(bottom, bg=C_BG)
        btns.pack(fill="x", pady=(8, 0))
        tk.Button(
            btns, text=u"Enviar", command=self.send,
            bg=C_BTN_TEAL, fg="#FFFFFF", activebackground=C_TEAL,
            font=ui_font(10, True), relief="flat", padx=16, pady=6,
            highlightthickness=0,
        ).pack(side="left", padx=(0, 6))
        tk.Button(
            btns, text=u"Modo examen", command=self.exam,
            bg=C_BTN_CORAL, fg="#FFFFFF", activebackground=C_CORAL,
            font=ui_font(10, True), relief="flat", padx=12, pady=6,
            highlightthickness=0,
        ).pack(side="left", padx=(0, 6))
        tk.Button(
            btns, text=u"Limpiar chat", command=self.clear,
            bg=C_BTN_SOFT, fg=C_LAV, relief="flat", font=ui_font(9),
            padx=10, pady=6, highlightthickness=0,
        ).pack(side="left", padx=(0, 6))
        tk.Button(
            btns, text=u"Releer clave", command=self.refresh_status,
            bg=C_BTN_SOFT, fg=C_LAV, relief="flat", font=ui_font(9),
            padx=10, pady=6, highlightthickness=0,
        ).pack(side="left")

    def _build_status_bar(self):
        self.status = tk.Label(
            self.root, text=u"", anchor="w", bg=C_BG, fg=C_MUTED,
            font=ui_font(8), padx=14, pady=8,
        )
        self.status.pack(fill="x", side="bottom")

    def _paint_chips(self):
        for n, b in self.chip_btns.items():
            if n == self.subject:
                b.configure(bg=C_CHIP_ON, fg=C_CHIP_ON_FG)
            else:
                b.configure(bg=C_CHIP, fg=C_CHIP_FG)

    def use_custom_subject(self):
        name = self.custom_subj.get().strip()
        if not name:
            self.append_sys(u"Escribí el nombre de la materia personalizada.")
            return
        self.set_subject(name)

    def set_subject(self, name):
        if self.busy:
            return
        save_history(self.subject, self.history)
        self.subject = name
        self.history = load_history(name)
        self._paint_chips()
        if name not in self.chip_btns:
            for b in self.chip_btns.values():
                b.configure(bg=C_CHIP, fg=C_CHIP_FG)
        self._reload_chat_from_history()
        self.refresh_status()
        if not self.history:
            self.append_sys(u"Materia: %s. Historial vacío — preguntá lo que necesites." % name)

    def _reload_chat_from_history(self):
        self.chat.configure(state="normal")
        self.chat.delete("1.0", "end")
        self.chat.configure(state="disabled")
        for h in self.history:
            if h["role"] == "user":
                self._write(u"Vos", h["text"], "user")
            else:
                self._write(u"NEXO", h["text"], "bot")

    def refresh_status(self):
        if self.status is None:
            return
        key = read_api_key()
        note_bit = u""
        if self.note_name:
            note_bit = u" · Apunte: %s" % self.note_name
        elif self.note_text:
            note_bit = u" · Apunte pegado (%d chars)" % len(self.note_text)
        if not key or len(key) < 10:
            self.status.configure(
                text=u"Falta la clave en config.txt (aistudio.google.com/apikey) · Materia: %s%s"
                % (self.subject, note_bit),
                fg=C_ERR,
            )
        else:
            self.status.configure(
                text=u"Clave OK · %s · flash free · %s%s"
                % (self.subject, VERSION, note_bit),
                fg=C_OK,
            )

    def refresh_plan_list(self):
        self.plan_list.delete(0, "end")
        today = datetime.now().date()
        shown = 0
        for item in self.plan:
            try:
                d = datetime.strptime(item["date"][:10], "%Y-%m-%d").date()
                delta = (d - today).days
                if delta < -1:
                    continue
                when = d.strftime("%d/%m")
                if delta == 0:
                    label = u"HOY %s · %s" % (when, item["topic"])
                elif delta == 1:
                    label = u"Mañana %s · %s" % (when, item["topic"])
                else:
                    label = u"%s · %s" % (when, item["topic"])
            except Exception:
                label = u"%s · %s" % (item.get("date", "?"), item.get("topic", "?"))
            self.plan_list.insert("end", label)
            shown += 1
            if shown >= 12:
                break
        if shown == 0:
            self.plan_list.insert("end", u"(sin exámenes)")

    def add_exam_dialog(self):
        win = tk.Toplevel(self.root)
        win.title(u"Agregar examen")
        win.configure(bg=C_BG)
        win.geometry("360x220")
        win.transient(self.root)
        win.grab_set()

        tk.Label(win, text=u"Fecha (AAAA-MM-DD)", bg=C_BG, fg=C_MUTED,
                 font=ui_font(8)).pack(anchor="w", padx=12, pady=(12, 2))
        date_e = tk.Entry(win, font=ui_font(10), relief="flat",
                          highlightthickness=1, highlightbackground=C_BORDER)
        date_e.pack(fill="x", padx=12)
        date_e.insert(0, datetime.now().strftime("%Y-%m-%d"))

        tk.Label(win, text=u"Tema / unidad", bg=C_BG, fg=C_MUTED,
                 font=ui_font(8)).pack(anchor="w", padx=12, pady=(8, 2))
        topic_e = tk.Entry(win, font=ui_font(10), relief="flat",
                           highlightthickness=1, highlightbackground=C_BORDER)
        topic_e.pack(fill="x", padx=12)

        tk.Label(win, text=u"Materia (opcional)", bg=C_BG, fg=C_MUTED,
                 font=ui_font(8)).pack(anchor="w", padx=12, pady=(8, 2))
        subj_e = tk.Entry(win, font=ui_font(10), relief="flat",
                          highlightthickness=1, highlightbackground=C_BORDER)
        subj_e.pack(fill="x", padx=12)
        subj_e.insert(0, self.subject)

        def save():
            date = date_e.get().strip()
            topic = topic_e.get().strip()
            subject = subj_e.get().strip() or self.subject
            try:
                datetime.strptime(date[:10], "%Y-%m-%d")
            except Exception:
                messagebox.showerror(u"Fecha", u"Usá el formato AAAA-MM-DD (ej: 2026-11-15).")
                return
            if not topic:
                messagebox.showerror(u"Tema", u"Escribí el tema del examen.")
                return
            self.plan.append({"date": date[:10], "topic": topic, "subject": subject})
            self.plan = sort_plan(self.plan)
            save_plan(self.plan)
            self.refresh_plan_list()
            win.destroy()

        tk.Button(
            win, text=u"Guardar", command=save,
            bg=C_BTN_PLAN, fg="#FFFFFF", relief="flat", font=ui_font(10, True),
            padx=12, pady=5, highlightthickness=0,
        ).pack(pady=14)

    def remove_selected_exam(self):
        sel = self.plan_list.curselection()
        if not sel:
            return
        idx = sel[0]
        today = datetime.now().date()
        visible = []
        for i, item in enumerate(self.plan):
            try:
                d = datetime.strptime(item["date"][:10], "%Y-%m-%d").date()
                if (d - today).days < -1:
                    continue
            except Exception:
                pass
            visible.append(i)
            if len(visible) >= 12:
                break
        if idx >= len(visible):
            return
        real = visible[idx]
        self.plan.pop(real)
        save_plan(self.plan)
        self.refresh_plan_list()

    def load_note(self):
        path = filedialog.askopenfilename(
            title=u"Elegí un apunte",
            filetypes=[
                (u"Texto / Markdown", "*.txt *.md"),
                (u"PDF (opcional)", "*.pdf"),
                (u"Todos", "*.*"),
            ],
        )
        if not path:
            return
        text, err = read_note_file(path)
        if err:
            messagebox.showwarning(u"Apunte", err)
            if text is None:
                return
        if text is None:
            return
        self.note_text = text
        self.note_name = os.path.basename(path)
        if len(text) >= NOTE_CAP:
            self.note_label.configure(
                text=u"Apunte: %s (recortado a %d chars)" % (self.note_name, NOTE_CAP),
                fg=C_WARN,
            )
        else:
            self.note_label.configure(
                text=u"Apunte: %s (%d chars)" % (self.note_name, len(text)),
                fg=C_TEAL,
            )
        self.refresh_status()
        self.append_sys(
            u"Apunte cargado: %s. Lo voy a usar como contexto cuando preguntes."
            % self.note_name
        )

    def paste_note_dialog(self):
        win = tk.Toplevel(self.root)
        win.title(u"Pegar apunte")
        win.configure(bg=C_BG)
        win.geometry("520x400")
        win.transient(self.root)
        win.grab_set()
        tk.Label(
            win, text=u"Pegá el texto del apunte (máx ~%d caracteres):" % NOTE_CAP,
            bg=C_BG, fg=C_MUTED, font=ui_font(9),
        ).pack(anchor="w", padx=10, pady=(10, 4))
        box = ScrolledText.ScrolledText(
            win, wrap="word", font=ui_font(10), bg=C_CARD, fg=C_TEXT,
            relief="flat", padx=8, pady=8,
        )
        box.pack(fill="both", expand=True, padx=10, pady=4)

        def save():
            text = box.get("1.0", "end").strip()
            if not text:
                messagebox.showerror(u"Apunte", u"No hay texto.")
                return
            if len(text) > NOTE_CAP:
                text = text[:NOTE_CAP]
            self.note_text = text
            self.note_name = u"pegado"
            self.note_label.configure(
                text=u"Apunte pegado (%d chars)" % len(text), fg=C_TEAL,
            )
            self.refresh_status()
            self.append_sys(u"Apunte pegado listo (%d caracteres)." % len(text))
            win.destroy()

        tk.Button(
            win, text=u"Usar apunte", command=save,
            bg=C_BTN_TEAL, fg="#FFFFFF", relief="flat", font=ui_font(10, True),
            padx=12, pady=5, highlightthickness=0,
        ).pack(pady=10)

    def clear_note(self):
        self.note_text = u""
        self.note_name = u""
        self.note_label.configure(text=u"Sin apunte cargado", fg=C_MUTED)
        self.refresh_status()
        self.append_sys(u"Apunte quitado.")

    def _write(self, who, text, tag):
        self.chat.configure(state="normal")
        self.chat.insert("end", who + u"\n", tag)
        self.chat.insert("end", text + u"\n\n", "body")
        self.chat.configure(state="disabled")
        self.chat.see("end")

    def append_user(self, text):
        self._write(u"Vos", text, "user")

    def append_bot(self, who, text):
        self._write(who, text, "bot")

    def append_sys(self, text):
        self._write(u"NEXO", text, "sys")

    def clear(self):
        if self.busy:
            return
        self.history = []
        clear_history_file(self.subject)
        self.chat.configure(state="normal")
        self.chat.delete("1.0", "end")
        self.chat.configure(state="disabled")
        self.append_sys(u"Chat limpio (también borré el historial de %s)." % self.subject)

    def _get_input(self):
        text = self.input.get("1.0", "end").strip()
        self.input.delete("1.0", "end")
        return text

    def send(self):
        if self.busy:
            return
        text = self._get_input()
        if not text:
            return
        self.append_user(text)
        self.busy = True
        if self.status is not None:
            self.status.configure(text=u"Pensando…", fg=C_MUTED)
        self.root.update_idletasks()
        note = self.note_text or None
        try:
            reply, model, err = call_gemini(self.history, self.subject, text, note)
            if reply:
                self.append_bot(u"NEXO (%s)" % model, reply)
                save_history(self.subject, self.history)
            else:
                self.append_sys(u"Error: %s" % err)
        except Exception:
            self.append_sys(u"Error interno:\n%s" % traceback.format_exc())
        self.busy = False
        self.refresh_status()

    def exam(self):
        if self.busy:
            return
        tema = self.input.get("1.0", "end").strip()
        if not tema:
            self.append_sys(
                u"Para Modo examen: escribí un tema (ej: ecuaciones) y tocá Modo examen."
            )
            return
        self.input.delete("1.0", "end")
        prompt = (
            u"Armá un mini ensayo de práctica (modo examen) sobre: %s.\n"
            u"Dadme exactamente 3 preguntas claras, numeradas 1-2-3, acordes a la materia %s.\n"
            u"Después de las 3 preguntas, en una sección aparte llamada RESPUESTAS, "
            u"poné las respuestas breves comentadas.\n"
            u"Nivel secundario. Español rioplatense."
        ) % (tema, self.subject)
        self.append_user(u"[Modo examen] %s" % tema)
        self.busy = True
        if self.status is not None:
            self.status.configure(text=u"Armando 3 preguntas…", fg=C_MUTED)
        self.root.update_idletasks()
        note = self.note_text or None
        try:
            reply, model, err = call_gemini(self.history, self.subject, prompt, note)
            if reply:
                self.append_bot(u"NEXO examen (%s)" % model, reply)
                save_history(self.subject, self.history)
            else:
                self.append_sys(u"Error: %s" % err)
        except Exception:
            self.append_sys(u"Error interno:\n%s" % traceback.format_exc())
        self.busy = False
        self.refresh_status()


def main():
    ensure_data_dir()
    root = tk.Tk()
    NexoApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
