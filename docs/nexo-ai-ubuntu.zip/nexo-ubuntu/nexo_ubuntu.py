# -*- coding: utf-8 -*-
"""NEXO AI Ubuntu — tutor liviano para Ubuntu (~2 GB RAM). Python 3 + Tkinter + Grok (xAI)."""
from __future__ import print_function

import json
import os
import sys
import threading
import traceback

try:
    import urllib.request as urllib_request
    import urllib.error as urllib_error
except ImportError:
    import urllib2 as urllib_request
    urllib_error = urllib_request

try:
    import tkinter as tk
    from tkinter import messagebox, scrolledtext as ScrolledText
except ImportError:
    print(
        "Falta Tkinter.\n"
        "En Ubuntu:\n"
        "  sudo apt update\n"
        "  sudo apt install python3-tk\n"
        "Después:  python3 nexo_ubuntu.py"
    )
    sys.exit(1)

VERSION = "3.0.2-ubuntu"
# Modelos xAI (barato/rápido primero). grok-4.3 con reasoning none = chat rápido.
MODELS = [
    "grok-4.3",
    "grok-4.20-0309-non-reasoning",
    "grok-4-1-fast-non-reasoning",
]
API_URL = "https://api.x.ai/v1/chat/completions"
MAX_TURNS = 16
SUBJECTS = [
    u"Matemática",
    u"Historia",
    u"Biología",
    u"Lengua",
    u"Química",
    u"Física",
    u"Otras",
]

APP_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(APP_DIR, "config.txt")
PREFS_PATH = os.path.join(APP_DIR, "preferencias.txt")

# Paleta NEXO Ubuntu — base oscura suave + celeste
C_BG = "#0F1724"           # fondo app
C_SIDE = "#152033"         # sidebar
C_HEADER = "#1A2740"       # header
C_CARD = "#1E2D45"         # chat card
C_CHIP = "#243552"         # chip apagado
C_CHIP_ON = "#38BDF8"      # celeste activo
C_CHIP_ON_FG = "#0B1220"
C_CHIP_FG = "#A8C0D8"
C_ACCENT = "#38BDF8"       # celeste NEXO
C_ACCENT_DIM = "#0EA5E9"
C_USER = "#F472B6"         # usuario
C_BOT = "#38BDF8"          # bot
C_SYS = "#A78BFA"          # sistema
C_TEXT = "#E8EEF6"         # texto
C_MUTED = "#8BA0B8"        # status
C_BTN = "#0EA5E9"
C_BTN_EXAM = "#F43F5E"
C_BTN_SOFT = "#2A3B55"
C_INPUT_BG = "#152033"
C_OK = "#34D399"
C_ERR = "#FB7185"
C_BORDER = "#2A3F5C"


def ui_font(size=10, bold=False):
    weight = "bold" if bold else "normal"
    for family in ("DejaVu Sans", "Ubuntu", "Liberation Sans", "FreeSans", "TkDefaultFont"):
        try:
            return (family, size, weight) if bold else (family, size)
        except Exception:
            continue
    return ("TkDefaultFont", size, weight) if bold else ("TkDefaultFont", size)


def read_api_key():
    if not os.path.isfile(CONFIG_PATH):
        return ""
    try:
        f = open(CONFIG_PATH, "r")
        try:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                for prefix in ("GROK_API_KEY=", "XAI_API_KEY="):
                    if line.startswith(prefix):
                        return line[len(prefix):].strip().strip('"').strip("'")
        finally:
            f.close()
    except Exception:
        return ""
    return ""


def load_prefs():
    prefs = {"subject": SUBJECTS[0]}
    if not os.path.isfile(PREFS_PATH):
        return prefs
    try:
        f = open(PREFS_PATH, "r")
        try:
            for line in f:
                line = line.strip()
                if line.startswith("subject="):
                    val = line[len("subject="):].strip()
                    if val in SUBJECTS:
                        prefs["subject"] = val
        finally:
            f.close()
    except Exception:
        pass
    return prefs


def save_prefs(subject):
    try:
        f = open(PREFS_PATH, "w")
        try:
            f.write("subject=%s\n" % subject)
        finally:
            f.close()
    except Exception:
        pass


def system_prompt(subject):
    return (
        u"Sos NEXO, un tutor de estudio para estudiantes de secundaria/preparatoria "
        u"en Argentina/Uruguay. Hablá en español rioplatense natural (vos, dale, mirá), "
        u"claro y cercano, sin ser infantil. Materia actual: %s. "
        u"Explicá paso a paso. Si no estás seguro, decilo. No inventes datos. "
        u"No des respuestas solo para copiar en un examen: ayudá a entender. "
        u"Sé breve si alcanza, y más detallado si el tema lo pide. "
        u"Esta es NEXO AI Ubuntu (Grok / xAI): no hay fotos, PDF ni plan de estudio."
    ) % subject


def http_post_json(url, payload, api_key):
    data = json.dumps(payload)
    if isinstance(data, str) and not isinstance(data, bytes):
        data = data.encode("utf-8")
    req = urllib_request.Request(url, data=data)
    req.add_header("Content-Type", "application/json")
    req.add_header("Authorization", "Bearer %s" % api_key)
    try:
        resp = urllib_request.urlopen(req, timeout=90)
        raw = resp.read()
        code = getattr(resp, "code", 200)
        resp.close()
        return code, raw
    except urllib_error.HTTPError as e:
        raw = e.read()
        return e.code, raw


def parse_grok_reply(raw):
    if isinstance(raw, bytes):
        try:
            raw = raw.decode("utf-8")
        except Exception:
            raw = raw.decode("latin-1", "replace")
    obj = json.loads(raw)
    if "error" in obj:
        err = obj["error"]
        if isinstance(err, dict):
            return None, err.get("message", str(err))
        return None, str(err)
    choices = obj.get("choices") or []
    if not choices:
        return None, u"Respuesta vacía del modelo."
    msg = choices[0].get("message") or {}
    content = msg.get("content")
    if content:
        return content, None
    return None, u"Sin texto (finish=%s)" % choices[0].get("finish_reason")


def call_grok(history, subject, user_text):
    key = read_api_key()
    if not key or len(key) < 10:
        return None, None, (
            u"Falta GROK_API_KEY (o XAI_API_KEY) en config.txt. "
            u"Conseguí una en https://console.x.ai/ — la API de xAI es de pago."
        )

    history.append({"role": "user", "content": user_text})
    while len(history) > MAX_TURNS * 2:
        history.pop(0)

    messages = [{"role": "system", "content": system_prompt(subject)}]
    for h in history:
        role = h["role"]
        if role == "model":
            role = "assistant"
        messages.append({"role": role, "content": h["content"]})

    last_err = u""
    for model in MODELS:
        payload = {
            "model": model,
            "messages": messages,
            "temperature": 0.7,
            "max_tokens": 2048,
        }
        # grok-4.3 acepta reasoning_effort; "none" = chat rápido y más barato
        if model == "grok-4.3":
            payload["reasoning_effort"] = "none"
        try:
            code, raw = http_post_json(API_URL, payload, key)
            text, err = parse_grok_reply(raw)
            if 200 <= code < 300 and text:
                history.append({"role": "assistant", "content": text})
                while len(history) > MAX_TURNS * 2:
                    history.pop(0)
                return text, model, None
            if code in (401, 403):
                if history and history[-1]["role"] == "user":
                    history.pop()
                return None, None, (
                    u"Clave inválida o sin permiso (HTTP %s). "
                    u"Revisá config.txt y https://console.x.ai/"
                ) % code
            if code == 429:
                if history and history[-1]["role"] == "user":
                    history.pop()
                return None, None, (
                    u"Límite de uso / rate limit (429). "
                    u"Esperá un rato o revisá el crédito en console.x.ai."
                )
            last_err = u"HTTP %s %s [%s]" % (code, err or u"", model)
            if code in (400, 404):
                continue
        except Exception as e:
            last_err = u"%s [%s]" % (e, model)

    if history and history[-1]["role"] == "user":
        history.pop()
    return None, None, last_err or (
        u"No se pudo contactar a Grok (xAI). Revisá Internet y LEEME.txt."
    )


def last_user_topic(history):
    for h in reversed(history):
        if h.get("role") == "user":
            t = (h.get("content") or "").strip()
            if t.startswith(u"[Modo examen]") or t.startswith(u"[Repaso]"):
                continue
            if len(t) > 8:
                return t[:200]
    return u""


class NexoApp(object):
    def __init__(self, root):
        self.root = root
        self.history = []
        prefs = load_prefs()
        self.subject = prefs.get("subject", SUBJECTS[0])
        self.busy = False
        self.last_model = u""

        root.title(u"NEXO AI · Ubuntu")
        root.geometry("1020x700")
        root.minsize(780, 540)
        root.configure(bg=C_BG)

        # Layout: sidebar + main
        body = tk.Frame(root, bg=C_BG)
        body.pack(fill="both", expand=True)

        side = tk.Frame(body, bg=C_SIDE, width=168)
        side.pack(side="left", fill="y")
        side.pack_propagate(False)

        tk.Label(
            side, text=u"NEXO", fg=C_ACCENT, bg=C_SIDE,
            font=ui_font(16, True)
        ).pack(anchor="w", padx=14, pady=(16, 0))
        tk.Label(
            side, text=u"Ubuntu · Grok", fg=C_MUTED, bg=C_SIDE,
            font=ui_font(8)
        ).pack(anchor="w", padx=14, pady=(0, 12))

        tk.Label(
            side, text=u"MATERIAS", fg=C_MUTED, bg=C_SIDE,
            font=ui_font(8)
        ).pack(anchor="w", padx=14, pady=(4, 6))

        self.chip_btns = {}
        for name in SUBJECTS:
            b = tk.Button(
                side, text=name, relief="flat", bd=0, anchor="w",
                command=lambda n=name: self.set_subject(n),
                bg=C_CHIP, fg=C_CHIP_FG, activebackground=C_CHIP_ON,
                activeforeground=C_CHIP_ON_FG,
                font=ui_font(9), padx=12, pady=6,
                highlightthickness=0,
            )
            b.pack(fill="x", padx=10, pady=2)
            self.chip_btns[name] = b
        self.chip_btns[self.subject].configure(bg=C_CHIP_ON, fg=C_CHIP_ON_FG)

        tk.Label(
            side, text=u"", bg=C_SIDE
        ).pack(fill="both", expand=True)
        tk.Label(
            side, text=VERSION, fg=C_MUTED, bg=C_SIDE,
            font=ui_font(7)
        ).pack(anchor="w", padx=14, pady=(0, 12))

        main = tk.Frame(body, bg=C_BG)
        main.pack(side="left", fill="both", expand=True)

        # Header
        top = tk.Frame(main, bg=C_HEADER, padx=16, pady=12)
        top.pack(fill="x")
        tk.Label(
            top, text=u"Tutor de estudio", fg=C_TEXT, bg=C_HEADER,
            font=ui_font(14, True)
        ).pack(anchor="w")
        tk.Label(
            top,
            text=u"Chat + examen + repaso · clave xAI/Grok en config.txt · pensado para ~2 GB RAM",
            fg=C_MUTED, bg=C_HEADER, font=ui_font(8)
        ).pack(anchor="w", pady=(2, 0))

        # Chat card
        chat_frame = tk.Frame(main, bg=C_BORDER, padx=1, pady=1)
        chat_frame.pack(fill="both", expand=True, padx=12, pady=10)
        inner = tk.Frame(chat_frame, bg=C_CARD)
        inner.pack(fill="both", expand=True)
        self.chat = ScrolledText.ScrolledText(
            inner, wrap="word", bg=C_CARD, fg=C_TEXT,
            insertbackground=C_TEXT, font=ui_font(10),
            relief="flat", state="disabled", padx=12, pady=10,
            highlightthickness=0, bd=0,
        )
        self.chat.pack(fill="both", expand=True)
        self.chat.tag_config("user", foreground=C_USER, font=ui_font(10, True))
        self.chat.tag_config("bot", foreground=C_BOT, font=ui_font(10, True))
        self.chat.tag_config("sys", foreground=C_SYS, font=ui_font(10, True))
        self.chat.tag_config("body", foreground=C_TEXT, font=ui_font(10))

        # Input + buttons
        bottom = tk.Frame(main, bg=C_BG, padx=12, pady=4)
        bottom.pack(fill="x")
        input_wrap = tk.Frame(bottom, bg=C_BORDER, padx=1, pady=1)
        input_wrap.pack(fill="x")
        self.input = tk.Text(
            input_wrap, height=3, bg=C_INPUT_BG, fg=C_TEXT,
            insertbackground=C_TEXT, font=ui_font(10), relief="flat",
            padx=8, pady=6, highlightthickness=0, bd=0,
        )
        self.input.pack(fill="x")
        self.input.bind("<Control-Return>", lambda e: self.send())

        btns = tk.Frame(bottom, bg=C_BG)
        btns.pack(fill="x", pady=(8, 2))
        tk.Button(
            btns, text=u"Enviar", command=self.send,
            bg=C_BTN, fg="#FFFFFF", activebackground=C_ACCENT_DIM,
            font=ui_font(10, True), relief="flat", padx=14, pady=5,
            highlightthickness=0,
        ).pack(side="left", padx=(0, 6))
        tk.Button(
            btns, text=u"Modo examen", command=self.exam,
            bg=C_BTN_EXAM, fg="#FFFFFF", activebackground="#E11D48",
            font=ui_font(10, True), relief="flat", padx=12, pady=5,
            highlightthickness=0,
        ).pack(side="left", padx=(0, 6))
        tk.Button(
            btns, text=u"Repaso", command=self.repaso,
            bg="#6366F1", fg="#FFFFFF", activebackground="#4F46E5",
            font=ui_font(10, True), relief="flat", padx=12, pady=5,
            highlightthickness=0,
        ).pack(side="left", padx=(0, 6))
        tk.Button(
            btns, text=u"Limpiar", command=self.clear,
            bg=C_BTN_SOFT, fg=C_CHIP_FG, activebackground=C_HEADER,
            font=ui_font(9), relief="flat", padx=10, pady=5,
            highlightthickness=0,
        ).pack(side="left", padx=(0, 6))
        tk.Button(
            btns, text=u"Releer clave", command=self.refresh_status,
            bg=C_BTN_SOFT, fg=C_CHIP_FG, activebackground=C_HEADER,
            font=ui_font(9), relief="flat", padx=10, pady=5,
            highlightthickness=0,
        ).pack(side="left")

        # Status AFTER widgets that might call refresh — fix init order
        self.status = tk.Label(
            bottom, text=u"", anchor="w", bg=C_BG, fg=C_MUTED,
            font=ui_font(8)
        )
        self.status.pack(fill="x", pady=(6, 10))

        self.append_sys(
            u"Hola. Soy NEXO AI Ubuntu.\n"
            u"Elegí una materia a la izquierda, escribí tu duda y tocá Enviar.\n"
            u"Necesitás Internet y una clave de Grok (xAI) en config.txt.\n"
            u"Atajo: Ctrl+Enter envía. Modo examen arma ~5 preguntas. Repaso usa el último tema."
        )
        self.refresh_status()

    def set_subject(self, name):
        self.subject = name
        save_prefs(name)
        for n, b in self.chip_btns.items():
            if n == name:
                b.configure(bg=C_CHIP_ON, fg=C_CHIP_ON_FG)
            else:
                b.configure(bg=C_CHIP, fg=C_CHIP_FG)
        self.refresh_status()

    def refresh_status(self):
        if not hasattr(self, "status"):
            return
        key = read_api_key()
        model_hint = self.last_model or u"grok-4.3"
        if not key or len(key) < 10:
            self.status.configure(
                text=u"Falta la clave en config.txt (console.x.ai) · Materia: %s · %s"
                % (self.subject, VERSION),
                fg=C_ERR,
            )
        else:
            self.status.configure(
                text=u"Clave detectada · Materia: %s · Modelo: %s · %s"
                % (self.subject, model_hint, VERSION),
                fg=C_OK,
            )

    def _write(self, who, text, tag):
        self.chat.configure(state="normal")
        self.chat.insert("end", who + u"\n", tag)
        self.chat.insert("end", text + u"\n\n", "body")
        self.chat.configure(state="disabled")
        self.chat.see("end")

    def append_user(self, text):
        self._write(u"Vos", text, "user")

    def append_bot(self, who, text):
        self._write(who, text, "bot")

    def append_sys(self, text):
        self._write(u"NEXO", text, "sys")

    def clear(self):
        self.history = []
        self.chat.configure(state="normal")
        self.chat.delete("1.0", "end")
        self.chat.configure(state="disabled")
        self.append_sys(u"Chat limpio. Elegí materia y preguntá de nuevo.")

    def _get_input(self):
        text = self.input.get("1.0", "end").strip()
        self.input.delete("1.0", "end")
        return text

    def _run_async(self, user_display, prompt_for_api, status_msg):
        if self.busy:
            return
        self.append_user(user_display)
        self.busy = True
        self.status.configure(text=status_msg, fg=C_MUTED)

        def worker():
            reply, model, err = None, None, None
            try:
                reply, model, err = call_grok(self.history, self.subject, prompt_for_api)
            except Exception:
                err = u"Error interno:\n%s" % traceback.format_exc()

            def finish():
                if reply:
                    self.last_model = model or u""
                    self.append_bot(u"NEXO (%s)" % model, reply)
                else:
                    self.append_sys(u"Error: %s" % err)
                self.busy = False
                self.refresh_status()

            self.root.after(0, finish)

        threading.Thread(target=worker, daemon=True).start()

    def send(self):
        if self.busy:
            return
        text = self._get_input()
        if not text:
            return
        self._run_async(text, text, u"Pensando con Grok…")

    def exam(self):
        if self.busy:
            return
        tema = self.input.get("1.0", "end").strip()
        if not tema:
            self.append_sys(
                u"Para Modo examen: escribí un tema (ej: ecuaciones) y tocá Modo examen."
            )
            return
        self.input.delete("1.0", "end")
        prompt = (
            u"Armá un mini ensayo de práctica (modo examen) sobre: %s.\n"
            u"Dadme exactamente 5 preguntas claras, numeradas 1-2-3-4-5, "
            u"acordes a la materia %s.\n"
            u"Después de las 5 preguntas, en una sección aparte llamada RESPUESTAS, "
            u"poné las respuestas breves comentadas.\n"
            u"Nivel secundario. Español rioplatense."
        ) % (tema, self.subject)
        self._run_async(
            u"[Modo examen] %s" % tema,
            prompt,
            u"Armando 5 preguntas…",
        )

    def repaso(self):
        if self.busy:
            return
        tema = last_user_topic(self.history)
        if not tema:
            typed = self.input.get("1.0", "end").strip()
            if typed:
                tema = typed
                self.input.delete("1.0", "end")
            else:
                self.append_sys(
                    u"Repaso: primero chateá un tema, o escribilo en el cuadro y tocá Repaso."
                )
                return
        prompt = (
            u"Armá un repaso adaptativo corto sobre este tema (o el último que hablamos):\n"
            u"%s\n\n"
            u"Materia: %s.\n"
            u"Dadme 3 preguntas rápidas (sin opciones múltiples), numeradas, "
            u"y después las RESPUESTAS breves en una sección aparte.\n"
            u"Nivel secundario. Español rioplatense. Sé concreto."
        ) % (tema, self.subject)
        self._run_async(
            u"[Repaso] %s" % (tema[:80] + (u"…" if len(tema) > 80 else u"")),
            prompt,
            u"Armando repaso…",
        )


def main():
    root = tk.Tk()
    NexoApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
