#!/bin/bash
# Lanzador NEXO AI Ubuntu
cd "$(dirname "$0")" || exit 1
if command -v python3 >/dev/null 2>&1; then
  exec python3 nexo_ubuntu.py "$@"
elif command -v python >/dev/null 2>&1; then
  exec python nexo_ubuntu.py "$@"
else
  echo "No encontré python3 ni python. Instalá Python 3 + Tkinter."
  echo "  sudo apt install python3 python3-tk"
  echo "Ver LEEME.txt"
  exit 1
fi
